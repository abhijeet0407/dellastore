<?php
/*
Plugin Name:    ArexWorks Content Types
Plugin URI:     http://www.arexworks.com/
Description:    ArexWorks Content Types
Author:         Duy Pham
Author URI:     http://www.arexworks.com/
Version:        1.0.0
Text Domain:    arexworks-plugin
*/

// don't load directly
if (!defined('ABSPATH'))
	die('-1');
class Arexworks_Content_Types_Class {

	function __construct() {
		add_action( 'plugins_loaded', array( $this, 'load_text_domain' ) );
		add_action( 'init', array( $this, 'add_static_block_content_type' ) );
		add_action( 'init', array( $this, 'add_portfolio_content_type' ) );
		add_filter( 'post_row_actions', array( $this, 'remove_row_actions' ), 10, 1 );
		add_action( 'edit_form_before_permalink', array( $this, 'edit_form_before_permalink') );
	}

	function edit_form_before_permalink($post){
		if(isset($post->post_type) && $post->post_type == 'static_block'){
			echo '<style type="text/css">.wrap > #message a,#edit-slug-box,#minor-publishing-actions > #preview-action{display: none}</style>';
		}
	}

	function remove_row_actions( $actions )
	{
		if( get_post_type() === 'static_block' )
			unset( $actions['view'] );
		return $actions;
	}

	// load plugin text domain
	function load_text_domain() {
		load_plugin_textdomain( 'arexworks-plugin', false, dirname( plugin_basename(__FILE__) ) . '/languages' );
	}

	// Get content type labels
	function get_labels($singular_name, $name, $title = FALSE) {
		if( !$title )
			$title = $name;

		return array(
			"name" => $title,
			"singular_name" => $singular_name,
			"add_new" => __("Add New", 'arexworks-plugin'),
			"add_new_item" => sprintf( __("Add New %s", 'arexworks-plugin'), $singular_name),
			"edit_item" => sprintf( __("Edit %s", 'arexworks-plugin'), $singular_name),
			"new_item" => sprintf( __("New %s", 'arexworks-plugin'), $singular_name),
			"view_item" => sprintf( __("View %s", 'arexworks-plugin'), $singular_name),
			"search_items" => sprintf( __("Search %s", 'arexworks-plugin'), $name),
			"not_found" => sprintf( __("No %s found", 'arexworks-plugin'), $name),
			"not_found_in_trash" => sprintf( __("No %s found in Trash", 'arexworks-plugin'), $name),
			"parent_item_colon" => ""
		);
	}

	// Get content type taxonomy labels
	function get_taxonomy_labels($singular_name, $name) {
		return array(
			"name" => $name,
			"singular_name" => $singular_name,
			"search_items" => sprintf( __("Search %s", 'arexworks-plugin'), $name),
			"all_items" => sprintf( __("All %s", 'arexworks-plugin'), $name),
			"parent_item" => sprintf( __("Parent %s", 'arexworks-plugin'), $singular_name),
			"parent_item_colon" => sprintf( __("Parent %s:", 'arexworks-plugin'), $singular_name),
			"edit_item" => sprintf( __("Edit %", 'arexworks-plugin'), $singular_name),
			"update_item" => sprintf( __("Update %s", 'arexworks-plugin'), $singular_name),
			"add_new_item" => sprintf( __("Add New %s", 'arexworks-plugin'), $singular_name),
			"new_item_name" => sprintf( __("New %s Name", 'arexworks-plugin'), $singular_name),
			"menu_name" => $name,
		);
	}
	
	// Register Static Block Post Type
	function add_static_block_content_type(){
		$name = apply_filters( 'arexworks_filter_content_type_static_block_name', __( 'Blocks', 'arexworks-plugin' ) );
		$singular_name = apply_filters( 'arexworks_filter_content_type_static_block_singular_name', __( 'Block', 'arexworks-plugin' ) );
		$slug_name = apply_filters( 'arexworks_filter_content_type_static_block_slug', 'static-block' );
		register_post_type(
			'static_block',
			array(
				'labels' => $this->get_labels( $singular_name, $name ),
				'has_archive'           => false,
				'can_export'            => true,
				'supports'              => array('title', 'editor'),
				'menu_position'         => 6,
				'menu_icon'             => 'dashicons-slides',
				'public'                => true,
				'exclude_from_search'   => true,
				'publicly_queryable'    => true,
				'show_ui'               => true,
				'show_in_menu'          => true,
				'show_in_nav_menus'     => false,
				'show_in_admin_bar'     => false,
				'rewrite'               => false,
				'capability_type'       => 'page',
			)
		);
	}

	// Porfolio content type
	function add_portfolio_content_type(){
		$name               = apply_filters( 'arexworks_filter_content_type_portfolio_name', __( 'Portfolios', 'arexworks-plugin' ) );
		$singular_name      = apply_filters( 'arexworks_filter_content_type_portfolio_name', __( 'Portfolio', 'arexworks-plugin' ) );
		$slug_name          = apply_filters( 'arexworks_filter_content_type_portfolio_slug', 'portfolio' );

		$cat_name           = apply_filters( 'arexworks_filter_content_type_portfolio_cat_name', __( 'Portfolio Category', 'arexworks-plugin' ) );
		$cats_name          = apply_filters( 'arexworks_filter_content_type_portfolio_cat_name', __( 'Portfolio Categories', 'arexworks-plugin' ) );

		$skill_name         = apply_filters( 'arexworks_filter_content_type_portfolio_skill_name', __( 'Portfolio Skill', 'arexworks-plugin' ) );
		$skills_name        = apply_filters( 'arexworks_filter_content_type_portfolio_skill_name', __( 'Portfolio Skills', 'arexworks-plugin' ) );

		$cat_slug_name      = apply_filters( 'arexworks_filter_content_type_portfolio_cat_slug', 'portfolio-category' );
		$skill_slug_name    = apply_filters( 'arexworks_filter_content_type_portfolio_skill_slug', 'portfolio-skill' );

		register_post_type(
			'portfolio',
			array(
				'labels' => $this->get_labels($singular_name, $name),
				'exclude_from_search' => false,
				'has_archive' => true,
				'public' => true,
				'rewrite' => array( 'slug' => $slug_name ),
				'supports' => array('title', 'editor', 'thumbnail', 'comments', 'page-attributes'),
				'can_export' => true,
				'menu_position' => 7,
				'menu_icon' => 'dashicons-portfolio'
			)
		);

		register_taxonomy(
			'portfolio_category',
			'portfolio',
			array(
				'hierarchical' => true,
				'show_in_nav_menus' => true,
				'labels' => $this->get_taxonomy_labels($cat_name, $cats_name),
				'query_var' => true,
				'show_admin_column' => true,
				'rewrite' => array('slug' => $cat_slug_name)
			)
		);

		register_taxonomy(
			'portfolio_skill',
			'portfolio',
			array(
				'hierarchical' => false,
				'show_in_nav_menus' => true,
				'labels' => $this->get_taxonomy_labels($skill_name, $skills_name),
				'query_var' => true,
				'show_admin_column' => true,
				'rewrite' => array('slug' => $skill_slug_name)
			)
		);
	}

}
new Arexworks_Content_Types_Class();



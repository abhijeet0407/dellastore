<?php
/*
Plugin Name:    ArexWorks Shortcodes
Plugin URI:     http://www.arexworks.com/
Description:    Arexworks Shortcode
Author:         Duy Pham
Author URI:     http://www.arexworks.com/
Version:        1.0.1
Text Domain:    arexworks-plugin
*/

// don't load directly
if (!defined('ABSPATH'))
	die('-1');

define('AREXWORKS_SHORTCODES_URL', plugin_dir_url(__FILE__));
define('AREXWORKS_SHORTCODES_PATH', dirname(__FILE__) . '/shortcodes/');
define('AREXWORKS_SHORTCODES_WOO_PATH', dirname(__FILE__) . '/woo_shortcodes/');
define('AREXWORKS_SHORTCODES_LIB', dirname(__FILE__) . '/lib/');
define('AREXWORKS_SHORTCODES_TEMPLATES', dirname(__FILE__) . '/templates/');
define('AREXWORKS_SHORTCODES_WOO_TEMPLATES', dirname(__FILE__) . '/woo_templates/');

class Arexworks_Shortcodes_Class {

	private $shortcodes = array(
		'arexworks_static_block',
		'arexworks_show_posts',
		'arexworks_show_portfolios',
		'arexworks_testimonial',
		'arexworks_member',
		'arexworks_social'
	);

	private $woo_shortcodes = array(
		'arexworks_show_product',
		'arexworks_register_page'
	);

	function __construct() {

		// Load text domain
		add_action( 'plugins_loaded', array( $this, 'load_text_domain' ) );

		$this->add_shortcodes();

		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		add_filter( 'the_content', array( $this, 'formatting' ) );
		add_filter( 'widget_text', array( $this, 'formatting' ) );
	}

	// load plugin text domain
	function load_text_domain() {
		load_plugin_textdomain( 'arexworks-plugin', false, dirname( plugin_basename(__FILE__) ) . '/languages' );
	}

	// load css and js
	function admin_enqueue_scripts() {
		wp_register_style( 'arexworks_shortcodes_admin', AREXWORKS_SHORTCODES_URL . 'assets/css/admin.css' );
		wp_enqueue_style( 'arexworks_shortcodes_admin' );
	}

	// Add shortcodes
	function add_shortcodes() {

		if (function_exists('get_plugin_data')) {
			$plugin = get_plugin_data(dirname(__FILE__) . '/arexworks-shortcodes.php');
			define('AREXWORKS_SHORTCODES_VERSION', $plugin['Version']);
		} else {
			define('AREXWORKS_SHORTCODES_VERSION', '');
		}
		include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		require_once(AREXWORKS_SHORTCODES_LIB . 'functions.php');
		foreach ($this->shortcodes as $shortcode) {
			require_once(AREXWORKS_SHORTCODES_PATH . $shortcode . '.php');
		}

		if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
			foreach ($this->woo_shortcodes as $woo_shortcode) {
				require_once(AREXWORKS_SHORTCODES_WOO_PATH . $woo_shortcode . '.php');
			}
		}
	}

	// Format shortcodes content
	function formatting($content) {
		$block = join("|", $this->shortcodes);
		// opening tag
		$content = preg_replace("/(<p>)?\[($block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]", $content);
		// closing tag
		$content = preg_replace("/(<p>)?\[\/($block)](<\/p>|<br \/>)/","[/$2]", $content);

		$woo_block = join("|", $this->woo_shortcodes);
		// opening tag
		$content = preg_replace("/(<p>)?\[($woo_block)(\s[^\]]+)?\](<\/p>|<br \/>)?/","[$2$3]", $content);
		// closing tag
		$content = preg_replace("/(<p>)?\[\/($woo_block)](<\/p>|<br \/>)/","[/$2]", $content);

		return $content;
	}

}

// Finally initialize code
new Arexworks_Shortcodes_Class();

global $arexworks_ult_assets;

add_action('wp_loaded', 'arexwrosk_get_ult_path');

function arexwrosk_get_ult_path() {
	global $arexworks_ult_assets;
	if (class_exists('Ultimate_VC_Addons')) {
		$uvc_addons = new Ultimate_VC_Addons();
		$uvc_addons->aio_front_scripts();
		$arexworks_ult_assets = str_replace('js/', '', $uvc_addons->assets_js);
	}
}
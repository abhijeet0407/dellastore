<?php

if ( !function_exists( 'arexworks_shortcode_template' ) ){
	function arexworks_shortcode_template( $name = false ) {
		if (!$name)
			return false;

		if ( $overridden_template = locate_template( 'vc_templates' . $name . '.php' ) ) {
			return $overridden_template;
		} else {
			// If neither the child nor parent theme have overridden the template,
			// we load the template from the 'templates' sub-directory of the directory this file is in
			return AREXWORKS_SHORTCODES_TEMPLATES . $name . '.php';
		}
	}
}

if ( !function_exists( 'arexworks_shortcode_woo_template' ) ) {
	function arexworks_shortcode_woo_template( $name = false )
	{
		if ( !$name )
			return false;

		if ( $overridden_template = locate_template( 'vc_templates' . $name . '.php' ) ) {
			return $overridden_template;
		} else {
			// If neither the child nor parent theme have overridden the template,
			// we load the template from the 'templates' sub-directory of the directory this file is in
			return AREXWORKS_SHORTCODES_WOO_TEMPLATES . $name . '.php';
		}
	}
}

if ( !function_exists( 'arexworks_shortcode_extract_class' ) ) {
	function arexworks_shortcode_extract_class( $el_class )
	{
		$output = '';
		if ( $el_class != '' ) {
			$output = " " . str_replace( ".", "", $el_class );
		}

		return $output;
	}
}

if ( !function_exists( 'arexworks_shortcode_end_block_comment' ) ) {
	function arexworks_shortcode_end_block_comment( $string )
	{
		return WP_DEBUG ? '<!-- END ' . $string . ' -->' : '';
	}
}

if ( !function_exists( 'arexworks_parse_multi_attribute' ) ) {
	function arexworks_parse_multi_attribute($value, $default = array()){
		$result = $default;
		$params_pairs = explode('|', $value);
		if (!empty($params_pairs)) {
			foreach ($params_pairs as $pair) {
				$param = preg_split('/\:/', $pair);
				if (!empty($param[0]) && isset($param[1])) {
					$result[$param[0]] = rawurldecode($param[1]);
				}
			}
		}
		return $result;
	}
}

if ( !function_exists( 'arexworks_shortcode_js_remove_wpautop' ) ) {
	function arexworks_shortcode_js_remove_wpautop( $content, $autop = false )
	{

		if ( $autop ) {
			$content = wpautop( preg_replace( '/<\/?p\>/', "\n", $content ) . "\n" );
		}

		return do_shortcode( shortcode_unautop( $content ) );
	}
}

if ( !function_exists( 'arexworks_shortcode_image_resize' ) ) {
	function arexworks_shortcode_image_resize( $attach_id = null, $img_url = null, $width, $height, $crop = false )
	{
		// this is an attachment, so we have the ID
		$image_src = array();
		if ( $attach_id ) {
			$image_src = wp_get_attachment_image_src( $attach_id, 'full' );
			$actual_file_path = get_attached_file( $attach_id );
			// this is not an attachment, let's use the image url
		} else if ( $img_url ) {
			$file_path = parse_url( $img_url );
			$actual_file_path = $_SERVER[ 'DOCUMENT_ROOT' ] . $file_path[ 'path' ];
			$actual_file_path = ltrim( $file_path[ 'path' ], '/' );
			$actual_file_path = rtrim( ABSPATH, '/' ) . $file_path[ 'path' ];
			$orig_size = getimagesize( $actual_file_path );
			$image_src[ 0 ] = $img_url;
			$image_src[ 1 ] = $orig_size[ 0 ];
			$image_src[ 2 ] = $orig_size[ 1 ];
		}
		if ( !empty( $actual_file_path ) ) {
			$file_info = pathinfo( $actual_file_path );
			$extension = '.' . $file_info[ 'extension' ];

			// the image path without the extension
			$no_ext_path = $file_info[ 'dirname' ] . '/' . $file_info[ 'filename' ];

			$cropped_img_path = $no_ext_path . '-' . $width . 'x' . $height . $extension;

			// checking if the file size is larger than the target size
			// if it is smaller or the same size, stop right here and return
			if ( $image_src[ 1 ] > $width || $image_src[ 2 ] > $height ) {

				// the file is larger, check if the resized version already exists (for $crop = true but will also work for $crop = false if the sizes match)
				if ( file_exists( $cropped_img_path ) ) {
					$cropped_img_url = str_replace( basename( $image_src[ 0 ] ), basename( $cropped_img_path ), $image_src[ 0 ] );
					$vt_image = array(
						'url'    => $cropped_img_url,
						'width'  => $width,
						'height' => $height
					);

					return $vt_image;
				}

				// $crop = false
				if ( $crop == false ) {
					// calculate the size proportionaly
					$proportional_size = wp_constrain_dimensions( $image_src[ 1 ], $image_src[ 2 ], $width, $height );
					$resized_img_path = $no_ext_path . '-' . $proportional_size[ 0 ] . 'x' . $proportional_size[ 1 ] . $extension;

					// checking if the file already exists
					if ( file_exists( $resized_img_path ) ) {
						$resized_img_url = str_replace( basename( $image_src[ 0 ] ), basename( $resized_img_path ), $image_src[ 0 ] );

						$vt_image = array(
							'url'    => $resized_img_url,
							'width'  => $proportional_size[ 0 ],
							'height' => $proportional_size[ 1 ]
						);

						return $vt_image;
					}
				}

				// no cache files - let's finally resize it
				$img_editor = wp_get_image_editor( $actual_file_path );

				if ( is_wp_error( $img_editor ) || is_wp_error( $img_editor->resize( $width, $height, $crop ) ) ) {
					return array(
						'url'    => '',
						'width'  => '',
						'height' => ''
					);
				}

				$new_img_path = $img_editor->generate_filename();

				if ( is_wp_error( $img_editor->save( $new_img_path ) ) ) {
					return array(
						'url'    => '',
						'width'  => '',
						'height' => ''
					);
				}
				if ( !is_string( $new_img_path ) ) {
					return array(
						'url'    => '',
						'width'  => '',
						'height' => ''
					);
				}

				$new_img_size = getimagesize( $new_img_path );
				$new_img = str_replace( basename( $image_src[ 0 ] ), basename( $new_img_path ), $image_src[ 0 ] );

				// resized output
				$vt_image = array(
					'url'    => $new_img,
					'width'  => $new_img_size[ 0 ],
					'height' => $new_img_size[ 1 ]
				);

				return $vt_image;
			}

			// default output - without resizing
			$vt_image = array(
				'url'    => $image_src[ 0 ],
				'width'  => $image_src[ 1 ],
				'height' => $image_src[ 2 ]
			);

			return $vt_image;
		}
		return false;
	}
}

if ( !function_exists( 'arexworks_shortcode_get_image_by_size' ) ) {
	function arexworks_shortcode_get_image_by_size( $params = array( 'post_id' => null, 'attach_id' => null, 'thumb_size' => 'thumbnail', 'class' => '' ) )
	{
		//array( 'post_id' => $post_id, 'thumb_size' => $grid_thumb_size )
		if ( ( !isset( $params[ 'attach_id' ] ) || $params[ 'attach_id' ] == null ) && ( !isset( $params[ 'post_id' ] ) || $params[ 'post_id' ] == null ) ) {
			return false;
		}
		$post_id = isset( $params[ 'post_id' ] ) ? $params[ 'post_id' ] : 0;

		if ( $post_id ) {
			$attach_id = get_post_thumbnail_id( $post_id );
		} else {
			$attach_id = $params[ 'attach_id' ];
		}

		$thumb_size = $params[ 'thumb_size' ];
		$thumb_class = ( isset( $params[ 'class' ] ) && $params[ 'class' ] != '' ) ? $params[ 'class' ] . ' ' : '';

		global $_wp_additional_image_sizes;
		$thumbnail = '';

		if ( is_string( $thumb_size ) && ( ( !empty( $_wp_additional_image_sizes[ $thumb_size ] ) && is_array( $_wp_additional_image_sizes[ $thumb_size ] ) ) || in_array(
					$thumb_size, array(
					'thumbnail',
					'thumb',
					'medium',
					'large',
					'full'
				) ) )
		) {
			$thumbnail = wp_get_attachment_image( $attach_id, $thumb_size, false, array( 'class' => $thumb_class . 'attachment-' . $thumb_size ) );
		} elseif ( $attach_id ) {
			if ( is_string( $thumb_size ) ) {
				preg_match_all( '/\d+/', $thumb_size, $thumb_matches );
				if ( isset( $thumb_matches[ 0 ] ) ) {
					$thumb_size = array();
					if ( count( $thumb_matches[ 0 ] ) > 1 ) {
						$thumb_size[ ] = $thumb_matches[ 0 ][ 0 ]; // width
						$thumb_size[ ] = $thumb_matches[ 0 ][ 1 ]; // height
					} elseif ( count( $thumb_matches[ 0 ] ) > 0 && count( $thumb_matches[ 0 ] ) < 2 ) {
						$thumb_size[ ] = $thumb_matches[ 0 ][ 0 ]; // width
						$thumb_size[ ] = $thumb_matches[ 0 ][ 0 ]; // height
					} else {
						$thumb_size = false;
					}
				}
			}
			if ( is_array( $thumb_size ) ) {
				// Resize image to custom size
				$p_img = arexworks_shortcode_image_resize( $attach_id, null, $thumb_size[ 0 ], $thumb_size[ 1 ], true );
				$alt = trim( strip_tags( get_post_meta( $attach_id, '_wp_attachment_image_alt', true ) ) );
				$attachment = get_post( $attach_id );
				if ( !empty( $attachment ) ) {
					$title = trim( strip_tags( $attachment->post_title ) );

					if ( empty( $alt ) ) {
						$alt = trim( strip_tags( $attachment->post_excerpt ) ); // If not, Use the Caption
					}
					if ( empty( $alt ) ) {
						$alt = $title;
					} // Finally, use the title
					if ( $p_img ) {
						$img_class = '';
						//if ( $grid_layout == 'thumbnail' ) $img_class = ' no_bottom_margin'; class="'.$img_class.'"
						$thumbnail = '<img class="' . esc_attr( $thumb_class ) . '" src="' . esc_attr( $p_img[ 'url' ] ) . '" width="' . esc_attr( $p_img[ 'width' ] ) . '" height="' . esc_attr( $p_img[ 'height' ] ) . '" alt="' . esc_attr( $alt ) . '" title="' . esc_attr( $title ) . '" />';
					}
				}
			}
		}

		$p_img_large = wp_get_attachment_image_src( $attach_id, 'large' );

		return apply_filters(
			'vc_wpb_getimagesize', array(
			'thumbnail'   => $thumbnail,
			'p_img_large' => $p_img_large
		), $attach_id, $params );
	}
}

if ( !function_exists( 'arexworks_shortcode_compress_text' ) ) {
	function arexworks_shortcode_compress_text( $string )
	{
		/* remove comments */
		$string = preg_replace( '!/\*[^*]*\*+([^/][^*]*\*+)*/!', '', $string );
		/* remove tabs, spaces, newlines, etc. */
		$string = str_replace( array( "\r\n", "\r", "\n", "\t", '	', '	', '	' ), '', $string );
		return $string;
	}
}

if ( !function_exists( 'arexworks_shortcode_get_blog_display_type' ) ) {
	function arexworks_shortcode_get_blog_display_type(){
		return array(
			__( 'Full', 'arexworks-plugin' )      => 'full',
			__( 'Grid', 'arexworks-plugin' )      => 'grid',
			__( 'Slide', 'arexworks-plugin' )     => 'slide',
			__( 'Slide 2', 'arexworks-plugin' )     => 'slide2',
			__( 'Isotope', 'arexworks-plugin' )   => 'isotope'
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_get_portfolio_display_type' ) ){
	function arexworks_shortcode_get_portfolio_display_type(){
		return array(
			__( 'Layout 1', 'arexworks-plugin' )      => 'layout_1',
			__( 'Layout 2', 'arexworks-plugin' )      => 'layout_2',
			__( 'Layout 3', 'arexworks-plugin' )      => 'layout_3'
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_get_portfolio_display_image_type' ) ){
	function arexworks_shortcode_get_portfolio_display_image_type(){
		return array(
			__( 'Thumbnail', 'arexworks-plugin' )      => 'thumbnail',
			__( 'Medium', 'arexworks-plugin' )        => 'medium',
			__( 'Large', 'arexworks-plugin' ) => 'large',
			__( 'Full', 'arexworks-plugin' ) => 'full'
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_animation_type' ) ) {
	function arexworks_shortcode_vc_animation_type()
	{
		return array(
			"type"        => "arexworks_vc_animation_type",
			"heading"     => __( "Animation Type", 'arexworks-plugin' ),
			"param_name"  => "animation_type",
			"admin_label" => true
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_animation_duration' ) ) {
	function arexworks_shortcode_vc_animation_duration()
	{
		return array(
			"type"        => "textfield",
			"heading"     => __( "Animation Duration", 'arexworks-plugin' ),
			"param_name"  => "animation_duration",
			"description" => __( "numerical value (unit: milliseconds)", 'arexworks-plugin' ),
			"value"       => '1000'
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_animation_delay' ) ) {
	function arexworks_shortcode_vc_animation_delay()
	{
		return array(
			"type"        => "textfield",
			"heading"     => __( "Animation Delay", 'arexworks-plugin' ),
			"param_name"  => "animation_delay",
			"description" => __( "numerical value (unit: milliseconds)", 'arexworks-plugin' ),
			"value"       => '0'
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_custom_class' ) ) {
	function arexworks_shortcode_vc_custom_class()
	{
		return array(
			'type'        => 'textfield',
			'heading'     => __( 'Extra class name', 'arexworks-plugin' ),
			'param_name'  => 'el_class',
			'description' => __( 'If you wish to style particular content element differently, then use this field to add a class name and then refer to it in your css file.', 'arexworks-plugin' )
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_woo_order_by' ) ) {
	function arexworks_shortcode_vc_woo_order_by()
	{
		return array(
			'',
			__( 'Date', 'js_composer' )          => 'date',
			__( 'ID', 'js_composer' )            => 'ID',
			__( 'Author', 'js_composer' )        => 'author',
			__( 'Title', 'js_composer' )         => 'title',
			__( 'Modified', 'js_composer' )      => 'modified',
			__( 'Random', 'js_composer' )        => 'rand',
			__( 'Comment count', 'js_composer' ) => 'comment_count',
			__( 'Menu order', 'js_composer' )    => 'menu_order',
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_woo_order_way' ) ) {
	function arexworks_shortcode_vc_woo_order_way()
	{
		return array(
			'',
			__( 'Descending', 'js_composer' ) => 'DESC',
			__( 'Ascending', 'js_composer' )  => 'ASC',
		);
	}
}

if ( !function_exists( 'arexworks_shortcode_vc_widget_title' ) ) {
	function arexworks_shortcode_vc_widget_title( $params = array( 'title' => '' ) )
	{
		if ( $params[ 'title' ] == '' ) {
			return '';
		}

		$extraclass = ( isset( $params[ 'extraclass' ] ) ) ? " " . $params[ 'extraclass' ] : "";
		$output = '<h4 class="wpb_heading' . $extraclass . '">' . $params[ 'title' ] . '</h4>';

		return apply_filters( 'wpb_widget_title', $output, $params );
	}
}

if ( function_exists( 'vc_add_shortcode_param' ) ) {
	vc_add_shortcode_param('arexworks_vc_animation_type', 'arexworks_shortcode_vc_animation_type_field');
}

if ( !function_exists( 'arexworks_shortcode_vc_animation_type_field' ) ) {
	function arexworks_shortcode_vc_animation_type_field( $settings, $value )
	{
		$param_line = '<select name="' . $settings[ 'param_name' ] . '" class="wpb_vc_param_value dropdown wpb-input wpb-select ' . $settings[ 'param_name' ] . ' ' . $settings[ 'type' ] . '">';

		$param_line .= '<option value="">none</option>';

		$param_line .= '<optgroup label="' . __( 'Attention Seekers', 'arexworks-plugin' ) . '">';
		$options = array( "bounce", "flash", "pulse", "rubberBand", "shake", "swing", "tada", "wobble" );
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Bouncing Entrances', 'arexworks-plugin' ) . '">';
		$options = array( "bounceIn", "bounceInDown", "bounceInLeft", "bounceInRight", "bounceInUp" );
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Fading Entrances', 'arexworks-plugin' ) . '">';
		$options = array( "fadeIn", "fadeInDown", "fadeInDownBig", "fadeInLeft", "fadeInLeftBig", "fadeInRight", "fadeInRightBig", "fadeInUp", "fadeInUpBig" );
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Flippers', 'arexworks-plugin' ) . '">';
		$options = array( "flip", "flipInX", "flipInY" );//, "flipOutX", "flipOutY");
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Lightspeed', 'arexworks-plugin' ) . '">';
		$options = array( "lightSpeedIn" );//, "lightSpeedOut");
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Rotating Entrances', 'arexworks-plugin' ) . '">';
		$options = array( "rotateIn", "rotateInDownLeft", "rotateInDownRight", "rotateInUpLeft", "rotateInUpRight" );
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Sliders', 'arexworks-plugin' ) . '">';
		$options = array( "slideInDown", "slideInLeft", "slideInRight" );//, "slideOutLeft", "slideOutRight", "slideOutUp");
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '<optgroup label="' . __( 'Specials', 'arexworks-plugin' ) . '">';
		$options = array( "hinge", "rollIn" );//, "rollOut");
		foreach ( $options as $option ) {
			$selected = '';
			if ( $option == $value ) $selected = ' selected="selected"';
			$param_line .= '<option value="' . $option . '"' . $selected . '>' . $option . '</option>';
		}
		$param_line .= '</optgroup>';

		$param_line .= '</select>';

		return $param_line;
	}
}
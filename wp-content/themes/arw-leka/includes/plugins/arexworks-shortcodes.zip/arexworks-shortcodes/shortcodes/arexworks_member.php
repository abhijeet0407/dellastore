<?php

add_shortcode('arexworks_member', 'arexworks_shortcode_arexworks_member');
add_action('vc_after_init', 'arexworks_load_arexworks_member_shortcode');

if ( !function_exists( 'arexworks_shortcode_arexworks_member' ) ) {
	function arexworks_shortcode_arexworks_member( $atts, $content = null )
	{
		$output = apply_filters( 'arexworks_member_shortcode_filter', '', $atts, $content );
		if ( $output != '' ) {
			return $output;
		}
		ob_start();
		if ( $template = arexworks_shortcode_template( 'arexworks_member' ) )
			include $template;
		return ob_get_clean();
	}
}

if ( !function_exists( 'arexworks_load_arexworks_member_shortcode' ) ) {
	function arexworks_load_arexworks_member_shortcode()
	{
		$custom_class = arexworks_shortcode_vc_custom_class();

		vc_map(
			array(
				'name'     => "Arexworks " . __( 'Member', 'arexworks-plugin' ),
				'base'     => 'arexworks_member',
				'category' => __( 'Arexworks', 'arexworks-plugin' ),
				'icon'     => 'arexworks_member',
				'weight'   => -50,
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Name', 'arexworks-plugin' ),
						'param_name'  => 'name',
						'admin_label' => true
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Role', 'arexworks-plugin' ),
						'param_name'  => 'role',
						'admin_label' => true
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Company', 'arexworks-plugin' ),
						'param_name'  => 'company',
						'admin_label' => true
					),
					array(
						'type'       => 'label',
						'heading'    => __( 'Input Photo URL or Select Photo.', 'arexworks-plugin' ),
						'param_name' => 'label'
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Photo URL', 'arexworks-plugin' ),
						'param_name' => 'photo_url'
					),
					array(
						'type'       => 'attach_image',
						'heading'    => __( 'Photo', 'arexworks-plugin' ),
						'param_name' => 'photo_id'
					),
					array(
						'type'        => 'vc_link',
						'heading'     => __( 'Facebook Link', 'arexworks-plugin' ),
						'param_name'  => 'facebook_link'
					),
					array(
						'type'        => 'vc_link',
						'heading'     => __( 'Twitter Link', 'arexworks-plugin' ),
						'param_name'  => 'twitter_link'
					),
					array(
						'type'        => 'vc_link',
						'heading'     => __( 'Dribbble Link', 'arexworks-plugin' ),
						'param_name'  => 'dribbble_link'
					),
					array(
						'type'        => 'vc_link',
						'heading'     => __( 'Google Plus Link', 'arexworks-plugin' ),
						'param_name'  => 'google_plus_link'
					),
					array(
						'type'        => 'vc_link',
						'heading'     => __( 'Pinterest Link', 'arexworks-plugin' ),
						'param_name'  => 'pinterest_link'
					),
					$custom_class
				)
			) );

		if ( !class_exists( 'WPBakeryShortCode_Arexworks_Member' ) ) {
			class WPBakeryShortCode_Arexworks_Member extends WPBakeryShortCode
			{
			}
		}
	}
}
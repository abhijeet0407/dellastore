<?php

add_shortcode('arexworks_show_posts', 'arexworks_shortcode_arexworks_show_posts');
add_action('vc_after_init', 'arexworks_load_arexworks_show_posts_shortcode');

add_filter( 'vc_autocomplete_arexworks_show_posts_category__in_callback', 'arexworks_add_filter_vc_post_category_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_posts_category__in_render', 'arexworks_add_filter_vc_post_category_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_posts_category__not_in_callback', 'arexworks_add_filter_vc_post_category_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_posts_category__not_in_render', 'arexworks_add_filter_vc_post_category_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_posts_post__in_callback', 'arexworks_add_filter_vc_post_id_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_posts_post__in_render', 'arexworks_add_filter_vc_post_id_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_posts_post__not_in_callback', 'arexworks_add_filter_vc_post_id_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_posts_post__not_in_render', 'arexworks_add_filter_vc_post_id_renderByIdExact', 10, 1 );

if ( !function_exists( 'arexworks_shortcode_arexworks_show_posts' ) ) {
	function arexworks_shortcode_arexworks_show_posts($atts, $content = null) {
		$output = apply_filters('arexworks_show_posts_shortcode_filter', '',$atts, $content);
		if ( $output != ''){
			return $output;
		}
		ob_start();
		if ($template = arexworks_shortcode_template('arexworks_show_posts'))
			include $template;

		return ob_get_clean();
	}
}

if ( !function_exists( 'arexworks_load_arexworks_show_posts_shortcode' ) ) {
	function arexworks_load_arexworks_show_posts_shortcode()
	{
		$custom_class = arexworks_shortcode_vc_custom_class();
		$post_layout = arexworks_shortcode_get_blog_display_type();
		vc_map(
			array(
				"name"        => "Arexworks " . __( "Show Posts", 'arexworks-plugin' ),
				"base"        => "arexworks_show_posts",
				"category"    => __( "Arexworks", 'arexworks-plugin' ),
				"description" => __( "Display posts with arexworks themes style", "arexworks-pluin" ),
				"icon"        => "arexworks_show_posts",
				'weight'      => -50,
				"params"      => array(
					array(
						"type"        => "textfield",
						"heading"     => __( "Title", 'arexworks-plugin' ),
						"param_name"  => "title",
						"admin_label" => true
					),
					array(
						"type"        => "dropdown",
						"heading"     => __( "Post Layout", 'arexworks-plugin' ),
						"param_name"  => "post_layout",
						"std"         => "grid",
						"value"       => $post_layout,
						"admin_label" => true
					),
					array(
						'type'       => 'autocomplete',
						'heading'    => __( 'Category In:', 'arexworks-plugin' ),
						'param_name' => 'category__in',
						'settings'   => array(
							'unique_values'  => true,
							'multiple'       => true,
							'sortable'       => true,
							'groups'         => false,
							'min_length'     => 0,
							'auto_focus'     => true,
							'display_inline' => true, // In UI show results inline view
						),
					),
					array(
						'type'       => 'autocomplete',
						'heading'    => __( 'Category Not In:', 'arexworks-plugin' ),
						'param_name' => 'category__not_in',
						'settings'   => array(
							'unique_values'  => true,
							'multiple'       => true,
							'sortable'       => true,
							'groups'         => false,
							'min_length'     => 0,
							'auto_focus'     => true,
							'display_inline' => true, // In UI show results inline view
						),
					),
					array(
						'type'       => 'autocomplete',
						'heading'    => __( 'Post In:', 'arexworks-plugin' ),
						'param_name' => 'post__in',
						'settings'   => array(
							'unique_values'  => true,
							'multiple'       => true,
							'sortable'       => true,
							'groups'         => false,
							'min_length'     => 0,
							'auto_focus'     => true,
							'display_inline' => true, // In UI show results inline view
						),
					),
					array(
						'type'       => 'autocomplete',
						'heading'    => __( 'Post Not In:', 'arexworks-plugin' ),
						'param_name' => 'post__not_in',
						'settings'   => array(
							'unique_values'  => true,
							'multiple'       => true,
							'sortable'       => true,
							'groups'         => false,
							'min_length'     => 0,
							'auto_focus'     => true,
							'display_inline' => true, // In UI show results inline view
						),
					),
					array(
						"type"       => "dropdown",
						"heading"    => __( "Columns", 'arexworks-plugin' ),
						"param_name" => "columns",
						'dependency' => array( 'element' => 'post_layout', 'value' => array( 'grid', 'slide' , 'slide2', 'isotope' ) ),
						'std'        => '3',
						"value"      => array(
							__( '1', 'arexworks-plugin' ) => '1',
							__( '2', 'arexworks-plugin' ) => '2',
							__( '3', 'arexworks-plugin' ) => '3',
							__( '4', 'arexworks-plugin' ) => '4',
							__( '5', 'arexworks-plugin' ) => '5',
							__( '6', 'arexworks-plugin' ) => '6'
						)
					),
					array(
						"type"       => "textfield",
						"heading"    => __( "Posts Count", 'arexworks-plugin' ),
						"param_name" => "number",
						"value"      => '3'
					),

					array(
						"type" => "number",
						"class" => "",
						"heading" => __("Excerpt Length", 'arexworks-plugin'),
						"param_name" => "excerpt_length",
						"value" => 60,
						"min" => 10,
						"max" => 200,
					),

					array(
						'type' => 'checkbox',
						'heading' => __( 'infinite ?', 'arexworks-plugin' ),
						'param_name' => 'infinite',
						'description' => __( '', 'arexworks-plugin' ),
						'value' => array( __( 'Yes', 'arexworks-plugin' ) => 'yes' ),
						'dependency' => array( 'element' => 'post_layout', 'value' => array( 'slide', 'slide2' ) ),
					),
					array(
						'type' => 'checkbox',
						'heading' => __( 'Show Dots ?', 'arexworks-plugin' ),
						'param_name' => 'show_dots',
						'description' => __( '', 'arexworks-plugin' ),
						'value' => array( __( 'Yes', 'arexworks-plugin' ) => 'yes' ),
						'dependency' => array( 'element' => 'post_layout', 'value' => array( 'slide', 'slide2' ) ),
					),
					array(
						'type' => 'checkbox',
						'heading' => __( 'Show Navigation ?', 'arexworks-plugin' ),
						'param_name' => 'show_navs',
						'description' => __( '', 'arexworks-plugin' ),
						'value' => array( __( 'Yes', 'arexworks-plugin' ) => 'yes' ),
						'dependency' => array( 'element' => 'post_layout', 'value' => array( 'slide', 'slide2' ) ),
					),
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Custom Navigation Carousel Element", 'arexworks-plugin' ),
						"param_name" => "custom_nav_carousel",
						"value" => "",
						'dependency' => array(
							'element' => 'show_navs',
							'value' => array( 'yes' ),
						),
					),
					array(
						'type' => 'checkbox',
						'heading' => __( 'Auto Play ?', 'arexworks-plugin' ),
						'param_name' => 'autoplay',
						'description' => __( '', 'arexworks-plugin' ),
						'value' => array( __( 'Yes', 'arexworks-plugin' ) => 'yes' ),
						'dependency' => array( 'element' => 'post_layout', 'value' => array( 'slide', 'slide2' ) ),
					),
					array(
						"type" => "number",
						"class" => "",
						"heading" => __("Speed", 'arexworks-plugin'),
						"param_name" => "speed",
						"value" => 500,
						"min" => 100,
						"max" => 10000,
						"suffix" => "ms",
						"description" => __("Slide transition duration (in ms)", 'arexworks-plugin'),
						'dependency' => array(
							'element' => 'autoplay',
							'value' => array( 'yes' ),
						),
					),

					array(
						'type'       => 'checkbox',
						'heading'    => __( "Enable Filter", 'arexworks-plugin' ),
						'param_name' => 'enable_filter',
						'dependency' => array( 'element' => 'post_layout', 'value' => array( 'isotope' ) ),
					),
					array(
						'type'       => 'checkbox',
						'heading'    => __( "Show View More", 'arexworks-plugin' ),
						'param_name' => 'view_more',
						'value'      => array( __( 'Yes', 'js_composer' ) => 'yes' )
					),
					array(
						"type"       => "vc_link",
						"heading"    => __( "View More Link", 'arexworks-plugin' ),
						"param_name" => "view_more_link",
						'dependency' => array( 'element' => 'view_more', 'not_empty' => true ),
					),
					$custom_class
				)
			) );

		if ( !class_exists( 'WPBakeryShortCode_Arexworks_Show_Posts' ) ) {
			class WPBakeryShortCode_Arexworks_Show_Posts extends WPBakeryShortCode
			{
			}
		}
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_post_id_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_post_id_autocomplete_suggester( $query )
	{
		global $wpdb;
		$post_id = (int) $query;
		$array_posts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.ID AS id, a.post_title AS title
						FROM {$wpdb->posts} AS a
						WHERE a.post_type = 'post'
						AND a.post_status LIKE 'publish'
						AND ( a.ID = '%d' OR a.post_title LIKE '%%%s%%' )",
				$post_id > 0 ? $post_id : -1, stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $array_posts ) && !empty( $array_posts ) ) {
			foreach ( $array_posts as $value ) {
				$data = array();
				$data[ 'value' ] = $value[ 'id' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'title' ] ) > 0 ) ? ' - ' . __( 'Title', 'js_composer' ) . ': ' .
						$value[ 'title' ] : '' );
				$results[ ] = $data;
			}
		}

		return $results;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_post_category_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_post_category_autocomplete_suggester( $query, $slug = false )
	{
		global $wpdb;
		$cat_id = (int) $query;
		$query = trim( $query );
		$array_category = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
							FROM {$wpdb->term_taxonomy} AS a
							INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
							WHERE a.taxonomy = 'category' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )",
				$cat_id > 0 ? $cat_id : -1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

		$result = array();
		if ( is_array( $array_category ) && !empty( $array_category ) ) {
			foreach ( $array_category as $value ) {
				$data = array();
				$data[ 'value' ] = $slug ? $value[ 'slug' ] : $value[ 'id' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'name' ] ) > 0 ) ? ' - ' . __( 'Name', 'js_composer' ) . ': ' .
						$value[ 'name' ] : '' ) .
					( ( strlen( $value[ 'slug' ] ) > 0 ) ? ' - ' . __( 'Slug', 'js_composer' ) . ': ' .
						$value[ 'slug' ] : '' );
				$result[ ] = $data;
			}
		}

		return $result;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_post_category_renderByIdExact' ) ) {
	function arexworks_add_filter_vc_post_category_renderByIdExact( $query )
	{

		$query = $query[ 'value' ];
		$cat_id = (int) $query;
		$term = get_term( $cat_id, 'category' );

		$term_slug = $term->slug;
		$term_title = $term->name;
		$term_id = $term->term_id;

		$term_slug_display = '';
		if ( !empty( $term_slug ) ) {
			$term_slug_display = ' - ' . __( 'Slug', 'js_composer' ) . ': ' . $term_slug;
		}

		$term_title_display = '';
		if ( !empty( $term_title ) ) {
			$term_title_display = ' - ' . __( 'Title', 'js_composer' ) . ': ' . $term_title;
		}

		$term_id_display = __( 'Id', 'js_composer' ) . ': ' . $term_id;

		$data = array();
		$data[ 'value' ] = $term_id;
		$data[ 'label' ] = $term_id_display . $term_title_display . $term_slug_display;

		return !empty( $data ) ? $data : false;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_post_id_renderByIdExact' ) ) {
	function arexworks_add_filter_vc_post_id_renderByIdExact( $query )
	{
		$query = trim( $query[ 'value' ] ); // get value from requested
		if ( !empty( $query ) ) {
			// get post
			$post_object = get_post( (int) $query );
			if ( is_object( $post_object ) ) {
				$slug = $post_object->post_name;
				$title = $post_object->post_title;
				$post_id = $post_object->ID;

				$post_slug_display = '';
				if ( !empty( $slug ) ) {
					$post_slug_display = ' - ' . __( 'Slug', 'js_composer' ) . ': ' . $slug;
				}

				$post_title_display = '';
				if ( !empty( $title ) ) {
					$post_title_display = ' - ' . __( 'Title', 'js_composer' ) . ': ' . $title;
				}

				$post_id_display = __( 'Id', 'js_composer' ) . ': ' . $post_id;

				$data = array();
				$data[ 'value' ] = $post_id;
				$data[ 'label' ] = $post_id_display . $post_title_display . $post_slug_display;

				return !empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}
}
<?php

add_shortcode('arexworks_social', 'arexworks_shortcode_arexworks_social');
add_action('vc_after_init', 'arexworks_load_arexworks_social_shortcode');

if ( !function_exists( 'arexworks_shortcode_arexworks_social' ) ) {
	function arexworks_shortcode_arexworks_social( $atts, $content = null )
	{
		$output = apply_filters( 'arexworks_social_shortcode_filter', '', $atts, $content );
		if ( $output != '' ) {
			return $output;
		}
		ob_start();
		if ( $template = arexworks_shortcode_template( 'arexworks_social' ) )
			include $template;
		return ob_get_clean();
	}
}

if ( !function_exists( 'arexworks_load_arexworks_social_shortcode' ) ) {
	function arexworks_load_arexworks_social_shortcode()
	{
		$custom_class = arexworks_shortcode_vc_custom_class();

		vc_map(
			array(
				'name'     => "Arexworks " . __( 'Social', 'arexworks-plugin' ),
				'base'     => 'arexworks_social',
				'category' => __( 'Arexworks', 'arexworks-plugin' ),
				'icon'     => 'arexworks_social',
				'weight'   => -50,
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Title', 'arexworks-plugin' ),
						'param_name'  => 'title',
						'admin_label' => true
					),

					$custom_class
				)
			) );

		if ( !class_exists( 'WPBakeryShortCode_Arexworks_Social' ) ) {
			class WPBakeryShortCode_Arexworks_Social extends WPBakeryShortCode
			{
			}
		}
	}
}
<?php

add_shortcode('arexworks_static_block', 'arexworks_shortcode_arexworks_static_block');
add_action('vc_after_init', 'arexworks_load_arexworks_static_block_shortcode');

add_filter( 'vc_autocomplete_arexworks_static_block_id_callback', 'arexworks_add_filter_vc_static_block_id_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_static_block_name_callback', 'arexworks_add_filter_vc_static_block_name_autocomplete_suggester', 10, 1 );

if ( !function_exists( 'arexworks_shortcode_arexworks_static_block' ) ) {
	function arexworks_shortcode_arexworks_static_block( $atts, $content = null )
	{
		$output = apply_filters( 'arexworks_static_block_shortcode_filter', '', $atts, $content );
		if ( $output != '' ) {
			return $output;
		}
		ob_start();
		if ( $template = arexworks_shortcode_template( 'arexworks_static_block' ) ){
			include $template;
		}
		return ob_get_clean();
	}
}

if ( !function_exists( 'arexworks_load_arexworks_static_block_shortcode' ) ) {
	function arexworks_load_arexworks_static_block_shortcode()
	{
		$animation_type = arexworks_shortcode_vc_animation_type();
		$animation_duration = arexworks_shortcode_vc_animation_duration();
		$animation_delay = arexworks_shortcode_vc_animation_delay();
		$custom_class = arexworks_shortcode_vc_custom_class();

		vc_map(
			array(
				"name"     => "Arexworks " . __( "Static Block", 'arexworks-plugin' ),
				"base"     => "arexworks_static_block",
				"category" => __( "Arexworks", 'arexworks-plugin' ),
				"icon"     => "arexworks_static_block",
				'weight'   => -50,
				"params"   => array(
					array(
						"type"       => "label",
						"heading"    => __( "Input block id & slug name", 'arexworks-plugin' ),
						"param_name" => "label"
					),
					array(
						"type"        => "autocomplete",
						"heading"     => __( "Block ID", 'arexworks-plugin' ),
						"param_name"  => "id",
						"admin_label" => true,
						'settings'    => array(
							'unique_values'  => true,
							'multiple'       => false,
							'sortable'       => false,
							'groups'         => false,
							'min_length'     => 0,
							'auto_focus'     => true,
							'display_inline' => true, // In UI show results inline view
						),
					),

					array(
						"type"        => "autocomplete",
						"heading"     => __( "Block Slug", 'arexworks-plugin' ),
						"param_name"  => "name",
						"admin_label" => true,
						'settings'    => array(
							'unique_values'  => true,
							'multiple'       => false,
							'sortable'       => false,
							'groups'         => false,
							'min_length'     => 0,
							'auto_focus'     => true,
							'display_inline' => true, // In UI show results inline view
						),
					),

					$animation_type,
					$animation_duration,
					$animation_delay,
					$custom_class
				)
			) );

		if ( !class_exists( 'WPBakeryShortCode_Arexworks_Static_Block' ) ) {
			class WPBakeryShortCode_Arexworks_Static_Block extends WPBakeryShortCode
			{
			}
		}
	}
}


if ( !function_exists( 'arexworks_add_filter_vc_static_block_id_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_static_block_id_autocomplete_suggester( $query )
	{
		global $wpdb;
		$post_id = (int) $query;
		$array_posts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.ID AS id, a.post_title AS title
						FROM {$wpdb->posts} AS a
						WHERE a.post_type = 'static_block'
						AND a.post_status LIKE 'publish'
						AND ( a.ID = '%d' OR a.post_title LIKE '%%%s%%' )",
				$post_id > 0 ? $post_id : -1, stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $array_posts ) && !empty( $array_posts ) ) {
			foreach ( $array_posts as $value ) {
				$data = array();
				$data[ 'value' ] = $value[ 'id' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'title' ] ) > 0 ) ? ' - ' . __( 'Title', 'js_composer' ) . ': ' .
						$value[ 'title' ] : '' );
				$results[ ] = $data;
			}
		}

		return $results;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_static_block_name_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_static_block_name_autocomplete_suggester( $query )
	{
		global $wpdb;
		$post_id = (int) $query;
		$array_posts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.ID AS id, a.post_title AS title , a.post_name AS slug
						FROM {$wpdb->posts} AS a
						WHERE a.post_type = 'static_block'
						AND a.post_status LIKE 'publish'
						AND ( a.ID = '%d' OR a.post_title LIKE '%%%s%%' OR a.post_name LIKE '%%%s%%' )",
				$post_id > 0 ? $post_id : -1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $array_posts ) && !empty( $array_posts ) ) {
			foreach ( $array_posts as $value ) {
				$data = array();
				$data[ 'value' ] = $value[ 'slug' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'title' ] ) > 0 ) ? ' - ' . __( 'Title', 'js_composer' ) . ': ' .
						$value[ 'title' ] : '' );
				$results[ ] = $data;
			}
		}

		return $results;
	}
}
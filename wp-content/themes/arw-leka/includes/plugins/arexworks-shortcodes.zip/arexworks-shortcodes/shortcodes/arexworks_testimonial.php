<?php

add_shortcode('arexworks_testimonial', 'arexworks_shortcode_arexworks_testimonial');
add_action('vc_after_init', 'arexworks_load_arexworks_testimonial_shortcode');

if ( !function_exists( 'arexworks_shortcode_arexworks_testimonial' ) ) {
	function arexworks_shortcode_arexworks_testimonial( $atts, $content = null )
	{
		$output = apply_filters( 'arexworks_testimonial_shortcode_filter', '', $atts, $content );
		if ( $output != '' ) {
			return $output;
		}
		ob_start();
		if ( $template = arexworks_shortcode_template( 'arexworks_testimonial' ) )
			include $template;
		return ob_get_clean();
	}
}

if ( !function_exists( 'arexworks_load_arexworks_testimonial_shortcode' ) ) {
	function arexworks_load_arexworks_testimonial_shortcode()
	{
		$custom_class = arexworks_shortcode_vc_custom_class();

		vc_map(
			array(
				'name'     => "Arexworks " . __( 'Testimonial', 'arexworks-plugin' ),
				'base'     => 'arexworks_testimonial',
				'category' => __( 'Arexworks', 'arexworks-plugin' ),
				'icon'     => 'arexworks_testimonial',
				'weight'   => -50,
				'params'   => array(
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Name', 'arexworks-plugin' ),
						'param_name'  => 'name',
						'admin_label' => true
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Role', 'arexworks-plugin' ),
						'param_name'  => 'role',
						'admin_label' => true
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Company', 'arexworks-plugin' ),
						'param_name'  => 'company',
						'admin_label' => true
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Author Link', 'arexworks-plugin' ),
						'param_name'  => 'author_url',
						'admin_label' => true
					),
					array(
						'type'       => 'label',
						'heading'    => __( 'Input Photo URL or Select Photo.', 'arexworks-plugin' ),
						'param_name' => 'label'
					),
					array(
						'type'       => 'textfield',
						'heading'    => __( 'Photo URL', 'arexworks-plugin' ),
						'param_name' => 'photo_url'
					),
					array(
						'type'       => 'attach_image',
						'heading'    => __( 'Photo', 'arexworks-plugin' ),
						'param_name' => 'photo_id'
					),
					array(
						'type'        => 'textarea_html',
						'heading'     => __( 'Quote', 'arexworks-plugin' ),
						'param_name'  => 'content',
						'admin_label' => true,
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Style Type', 'arexworks-plugin' ),
						'param_name'  => 'style',
						'std'         => '',
						'value'       =>  array(
							__('Style 1', 'arexworks-plugin' ) => 'style-1',
							__('Style 2', 'arexworks-plugin' ) => 'style-2',
							__('Style 3', 'arexworks-plugin' ) => 'style-3'
						),
						'admin_label' => true
					),
					$custom_class
				)
			) );

		if ( !class_exists( 'WPBakeryShortCode_Arexworks_Testimonial' ) ) {
			class WPBakeryShortCode_Arexworks_Testimonial extends WPBakeryShortCode
			{
			}
		}
	}
}
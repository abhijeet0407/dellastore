<?php
$name = $role = $company = $photo_url = $photo_id = $facebook_link = $twitter_link = $dribbble_link = $google_plus_link = $pinterest_link = $el_class = '';
$output = '';
extract(shortcode_atts(array(
    'name' => '',
    'role' => '',
    'company' => '',
    'photo_url' => '',
    'photo_id' => '',
	'facebook_link' => '',
	'twitter_link' => '',
	'dribbble_link' => '',
	'google_plus_link' => '',
	'pinterest_link' => '',
    'el_class' => '',
), $atts));

$el_class = arexworks_shortcode_extract_class( $el_class );


if (!$photo_url && $photo_id)
    $photo_url = wp_get_attachment_url($photo_id);

$porto_url = str_replace(array('http:', 'https:'), '', $photo_url);

$output .= '<div class="arexworks-member wpb_content_element '. esc_attr($el_class) . '" >';
	$output .= '<div class="member-inner">';
		$output .= '<div class="member-thumbnail-wrapper">';
			if ($photo_url){
				$output .= '<img src="'.esc_url($photo_url).'" alt="'.esc_attr($name).'"/>';
			}
			$output .= '<div class="member-link">';
				// Facebook
				if ( $facebook_link ){
					$facebook_link = arexworks_parse_multi_attribute( $facebook_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
					$output .= '<a class="facebook-link"';
						$output .= 'href="' . esc_url($facebook_link['url']) . '" ';
						$output .= 'title="' . esc_attr($facebook_link['title']) . '" ';
						$output .= 'target="' . esc_attr($facebook_link['target']) . '" ';
						$output .= '>';
						$output .= '<i class="fa fa-facebook"></i>';
					$output .= '</a>';
				}
				// Twitter
				if ( $twitter_link ){
					$twitter_link = arexworks_parse_multi_attribute( $twitter_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
					$output .= '<a class="twitter-link"';
					$output .= 'href="' . esc_url($twitter_link['url']) . '" ';
					$output .= 'title="' . esc_attr($twitter_link['title']) . '" ';
					$output .= 'target="' . esc_attr($twitter_link['target']) . '" ';
					$output .= '>';
					$output .= '<i class="fa fa-twitter"></i>';
					$output .= '</a>';
				}

				// dribbble_link
				if ( $dribbble_link ) {
					$dribbble_link = arexworks_parse_multi_attribute( $dribbble_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
					$output .= '<a class="dribbble-link"';
					$output .= 'href="' . esc_url($dribbble_link['url']) . '" ';
					$output .= 'title="' . esc_attr($dribbble_link['title']) . '" ';
					$output .= 'target="' . esc_attr($dribbble_link['target']) . '" ';
					$output .= '>';
					$output .= '<i class="fa fa-dribbble"></i>';
					$output .= '</a>';
				}
				// $google_plus_link
				if ($google_plus_link) {
					$google_plus_link = arexworks_parse_multi_attribute( $google_plus_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
					$output .= '<a class="google-plus-link"';
					$output .= 'href="' . esc_url( $google_plus_link[ 'url' ] ) . '" ';
					$output .= 'title="' . esc_attr( $google_plus_link[ 'title' ] ) . '" ';
					$output .= 'target="' . esc_attr( $google_plus_link[ 'target' ] ) . '" ';
					$output .= '>';
					$output .= '<i class="fa fa-google-plus"></i>';
					$output .= '</a>';
				}

				// pinterest_link
				if ($pinterest_link) {
					$pinterest_link = arexworks_parse_multi_attribute( $pinterest_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
					$output .= '<a class="pinterest-link"';
					$output .= 'href="' . esc_url( $pinterest_link[ 'url' ] ) . '" ';
					$output .= 'title="' . esc_attr( $pinterest_link[ 'title' ] ) . '" ';
					$output .= 'target="' . esc_attr( $pinterest_link[ 'target' ] ) . '" ';
					$output .= '>';
					$output .= '<i class="fa fa-pinterest"></i>';
					$output .= '</a>';
				}

			$output .= '</div>';
			$output .= '<div class="member-overlay"></div>';
		$output .= '</div>';
		$output .= '<div class="member-info">';
			$output .= '<div class="member-name"><h4>'.esc_html($name).'</h4></div>';
			$output .= '<p><span>'.$role.(($role && $company)?' <i></i> ':'').$company.'</span></p>';
		$output .= '</div>';
	$output .= '</div>';
$output .= '</div>' . arexworks_shortcode_end_block_comment( 'arexworks_member' );

echo $output;
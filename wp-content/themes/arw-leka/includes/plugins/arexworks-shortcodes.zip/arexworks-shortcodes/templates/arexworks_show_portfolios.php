<?php
$title = $portfolio_layout = $portfolio_display_image_type = $columns = $category__in = $category__not_in = $post__in = $post__not_in = $number = '';
$view_more = $view_more_link = $el_class = '';
$enable_masonry = $enable_filter = '';
extract(shortcode_atts(array(
	'title' => '',
	'portfolio_layout' => 'layout_1',
	'portfolio_display_image_type' => 'thumbnail',
	'columns' => '3',
	'category__in' => '',
	'category__not_in' => '',
	'post__in' => '',
	'post__not_in' => '',
	'number' => '3',
	'enable_masonry' => false,
	'enable_filter' => false,
	'view_more' => false,
	'view_more_link' => '#',
	'el_class' => ''
), $atts ) );

$args = array(
	'post_type'             => 'portfolio',
	'post_status'		    => 'publish',
	'ignore_sticky_posts'   => 1,
	'posts_per_page'        => $number
);

if ( $category__in ) {
	$category__in = explode( ',', $category__in );
	$category__in = array_map( 'trim', $category__in );
}
if ( $category__not_in ) {
	$category__not_in = explode( ',', $category__not_in );
	$category__not_in = array_map( 'trim', $category__not_in );
}
if ( $post__in ) {
	$post__in = explode( ',', $post__in );
	$post__in = array_map( 'trim', $post__in );
}
if ( $post__not_in ) {
	$post__not_in = explode( ',', $post__not_in );
	$post__not_in = array_map( 'trim', $post__not_in );
}

$tax_query = array();
if ( !empty( $category__in ) && !empty( $category__not_in ) ){
	$tax_query['relation'] = 'AND';
}
if ( !empty ( $category__in ) ) {
	$tax_query[] = array(
		'taxonomy' => 'portfolio_category',
		'field'    => 'term_id',
		'terms'    => $category__in
	);
}
if ( !empty ( $category__not_in ) ) {
	$tax_query[] = array(
		'taxonomy' => 'portfolio_category',
		'field'    => 'term_id',
		'terms'    => $category__not_in,
		'operator' => 'NOT IN'
	);
}
if(!empty($tax_query)){
	$args['tax_query'] = $tax_query;
}
if ( !empty ( $post__in ) ) {
	$args['post__in'] = $post__in;
}
if ( !empty ( $post__not_in ) ) {
	$args['post__not_in'] = $post__not_in;
}

$the_query = new WP_Query($args);

global $arexworks_loop;

switch($columns){
	case '1':
		$class_block_grid = 'small-block-grid-1 medium-block-grid-1';
		break;
	case '2':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-2';
		break;
	case '3':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-3';
		break;
	case '4':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-3 large-block-grid-4';
		break;
	case '5':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-4 large-block-grid-5';
		break;
	case '6':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-4 large-block-grid-6';
		break;
	default:
		$class_block_grid = 'small-block-grid-2 medium-block-grid-3';
}

if ( $enable_masonry ){
	$class_block_grid .= ' arexworks-isotope-container';
}
$class_block_grid .= ' arexworks-portfolio-container';
$class_block_grid .= ' arexworks-portfolio-container-'.esc_attr($portfolio_layout);
$class_block_grid .= ' arexworks-portfolio-container-image-'.esc_attr($portfolio_display_image_type);
$rand_id = arexworks_generate_rand();

$portfolio_filter_by = array(
	'portfolio_skill'
);

if ( $the_query->have_posts() ) {

	$arexworks_loop['columns'] = $columns;
	$arexworks_loop['portfolio_layout'] = $portfolio_layout;
	$arexworks_loop['portfolio_image_type'] = $portfolio_display_image_type;
	$arexworks_loop['rand_id'] = $rand_id;

	$el_class = arexworks_shortcode_extract_class($el_class);
	$output = '<div class="arexworks-show-portfolios arexworks-posts-container wpb_content_element ' . $el_class . '">';
		$output .= arexworks_shortcode_vc_widget_title( array( 'title' => $title, 'extraclass' => '' ) );
	ob_start();
	?>
		<div class="arexworks-show-portfolios-inner">
			<div class="arexworks-show-portfolios-inner2">
				<?php
				$data_attribute_infinite = '';
				if( $enable_masonry ){
					$config_isotope = array(
						'layoutMode' => 'packery'
					);
					$data_attribute_infinite .= ' data-config_isotope="'.esc_attr(json_encode($config_isotope)).'" ';
				}

				$open_wrapper = '<div id="arexworks_portfolio_container_'.esc_attr($rand_id).'" class="'.esc_attr($class_block_grid).'" ' . $data_attribute_infinite . '>';
				$close_wrapper = '</div>';

				if( $enable_masonry ){
					$portfolio_filter_html = '';
					if ( $enable_filter ){
						$portfolio_filter_html = '<div class="portfolio-filter-wrapper isotope-filter-wrapper" data-isotope_container="#arexworks_portfolio_container_'.esc_attr($rand_id).'">';
						$portfolio_filter_html .= '<ul>';
						$portfolio_filter_html .= '<li data-filter="*" class="active"><a href="#">' . __('All', "arexworks-pluin") . '</a></li>';
						$terms = get_terms($portfolio_filter_by);
						if( $terms && ! is_wp_error($terms)){
							foreach ( $terms as $term ){
								$term_class = $term->taxonomy . '-' . $term->slug;
								if(!empty($category__not_in) && in_array($term->term_id,$category__not_in)){
									continue;
								}
								$portfolio_filter_html .=  '<li data-filter="' . esc_attr( $term_class ) . '"><a href="#">' . esc_html($term->name) . '</a></li>';
							}
						}
						$portfolio_filter_html .= '</ul>';
						$portfolio_filter_html .= '</div>';
					}
					$open_wrapper = '<div class="arexworks-isotope">' . $portfolio_filter_html . $open_wrapper;
					$isotope_loading_html = '<div class="arexworks-isotope-loading"><div></div></div>';
					$close_wrapper = $isotope_loading_html . '</div>' . $close_wrapper;
				}

				echo $open_wrapper;

				while($the_query->have_posts())
				{
					$the_query->the_post();
					get_template_part('template-shares/portfolio_loop/content');
				}

				echo $close_wrapper;
				?>
			</div>
		</div>
	<?php
	$output .= ob_get_clean();

	if ( $view_more ){
		$view_more_link_object = arexworks_parse_multi_attribute( $view_more_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
		$output .= '<div class="view-more-posts">';
		$output .= '<a class="button"';
		$output .= 'href="' . esc_url($view_more_link_object['url']) . '" ';
		$output .= 'title="' . esc_attr($view_more_link_object['title']) . '" ';
		$output .= 'target="' . esc_attr($view_more_link_object['target']) . '" ';
		$output .= 'data-query="'.esc_attr( json_encode($args) ).'" ';
		$output .= 'data-paged="1" ';
		$output .= 'data-arexworks_loop="' . esc_attr( json_encode($arexworks_loop) ) . '" ';
		$output .= '>';
		$output .= esc_html( $view_more_link_object['title'] );
		$output .= '</a>';
		$output .= '</div>';
	}
	$output .= '</div>' . arexworks_shortcode_end_block_comment( 'arexworks_show_portfolios' );
	echo $output;
}

$arexworks_loop = array();
wp_reset_postdata();
<?php
$title = $post_layout = $columns = $category__in = $category__not_in = $post__in = $post__not_in = $number = '';
$view_more = $view_more_link = $animation_type = $animation_duration = $animation_delay = $el_class = '';
$infinite = $show_dots = $show_navs = $custom_nav_carousel = $autoplay = $speed = $enable_filter = '';
$excerpt_length = '';
extract(shortcode_atts(array(
	'title' => '',
	'post_layout' => 'grid',
	'columns' => '3',
	'category__in' => '',
	'category__not_in' => '',
	'post__in' => '',
	'post__not_in' => '',
	'number' => '3',
	'excerpt_length' => 30,
	'enable_filter' => false,
	'view_more' => false,
	'view_more_link' => '#',
	'animation_type' => '',
	'animation_duration' => '',
	'animation_delay' => '',
	'infinite' => '',
	'show_dots' => '',
	'show_navs' => '',
	'custom_nav_carousel' => '',
	'autoplay' => '',
	'speed' => '300',
	'el_class' => ''
), $atts ) );

$args = array(
	'post_type'             => 'post',
	'post_status'		    => 'publish',
	'ignore_sticky_posts'   => 1,
	'posts_per_page'        => $number
);

if ( $category__in ) {
	$category__in = explode( ',', $category__in );
	$category__in = array_map( 'trim', $category__in );
}
if ( $category__not_in ) {
	$category__not_in = explode( ',', $category__not_in );
	$category__not_in = array_map( 'trim', $category__not_in );
}
if ( $post__in ) {
	$post__in = explode( ',', $post__in );
	$post__in = array_map( 'trim', $post__in );
}
if ( $post__not_in ) {
	$post__not_in = explode( ',', $post__not_in );
	$post__not_in = array_map( 'trim', $post__not_in );
}
if ( !empty ( $category__in ) ) {
	$args['category__in'] = $category__in;
}
if ( !empty ( $category__not_in ) ) {
	$args['category__not_in'] = $category__not_in;
}
if ( !empty ( $post__in ) ) {
	$args['post__in'] = $post__in;
}
if ( !empty ( $post__not_in ) ) {
	$args['post__not_in'] = $post__not_in;
}

$the_query = new WP_Query($args);

global $arexworks_loop;
$rand_id = arexworks_generate_rand();
switch($columns){
	case '1':
		$class_block_grid = 'small-block-grid-1 medium-block-grid-1';
		$medium_columns = 1;
		$small_columns = 1;
		break;
	case '2':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-2';
		$medium_columns = 2;
		$small_columns = 1;
		break;
	case '3':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-3';
		$medium_columns = 3;
		$small_columns = 1;
		break;
	case '4':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-3 large-block-grid-4';
		$medium_columns = 3;
		$small_columns = 1;
		break;
	case '5':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-4 large-block-grid-5';
		$medium_columns = 3;
		$small_columns = 1;
		break;
	case '6':
		$class_block_grid = 'small-block-grid-2 medium-block-grid-4 large-block-grid-6';
		$medium_columns = 3;
		$small_columns = 1;
		break;
	default:
		$class_block_grid = 'small-block-grid-2 medium-block-grid-3';
}
if ( $the_query->have_posts() ) {
	$el_class = arexworks_shortcode_extract_class($el_class);
	$output = '<div class="arexworks-show-posts arexworks-posts-container wpb_content_element ' . $el_class . '"';
	if ($animation_type)
		$output .= ' data-appear-animation="'.$animation_type.'"';
	if ($animation_delay)
		$output .= ' data-appear-animation-delay="'.$animation_delay.'"';
	if ($animation_duration && $animation_duration != 1000)
		$output .= ' data-appear-animation-duration="'.$animation_duration.'"';
	$output .= '>';

	$output .= arexworks_shortcode_vc_widget_title( array( 'title' => $title, 'extraclass' => '' ) );
	$arexworks_loop['columns'] = $columns;
	$arexworks_loop['post_layout'] = $post_layout;
	$arexworks_loop['rand_id'] = $rand_id;
	$arexworks_loop['excerpt_length'] = $excerpt_length;
	ob_start();
	?>
	<div class="arexworks-show-posts-inner">
		<div class="arexworks-show-posts-inner2">
			<?php
			if( $post_layout == 'slide' || $post_layout == 'slide2' ){
				$slider_config = array(
					'adaptiveHeight' => true,
					'infinite' => $infinite ? true : false,
					'slidesToShow' => intval($columns),
					'slidesToScroll' => intval($columns),
					'dots' => $show_dots ? true : false,
					'autoplay' => $autoplay ? true : false,
					'arrows' => $show_navs ? true : false,
					'speed' => intval($speed),
					'centerPadding' => 0,
					'responsive' => array(
						array(
							'breakpoint' => 1440,
							'settings' => array(
								'slidesToShow' => intval($columns),
								'slidesToScroll' => intval($columns)
							)
						),
						array(
							'breakpoint' => 992,
							'settings' => array(
								'slidesToShow' => intval($medium_columns),
								'slidesToScroll' => intval($medium_columns)
							)
						),
						array(
							'breakpoint' => 768,
							'settings' => array(
								'slidesToShow' => intval($small_columns),
								'slidesToScroll' => intval($small_columns)
							)
						),
						array(
							'breakpoint' => 480,
							'settings' => array(
								'slidesToShow' => 1,
								'slidesToScroll' => 1
							)
						)
					)
				);
				if(!empty($custom_nav_carousel)){
					$slider_config['appendArrows'] = 'jQuery("'.esc_attr($custom_nav_carousel).'")';
				}
				echo '<div id="arexworks_caroulsel_'. $rand_id .'" data-slider_config="'.esc_attr(json_encode($slider_config)).'" class="arexworks-show-post-slide arexworks-slick-slider row">';
			}
			if( $post_layout == 'grid' ){
				echo '<div class="'.esc_attr($class_block_grid).'">';
			}
			if( $post_layout == 'isotope' ){
				$class_block_grid .= ' arexworks-isotope-container';
				echo '<div class="arexworks-isotope">';
				if ( $enable_filter ){
					echo '<div class="isotope-filter-wrapper" data-isotope_container="#arexworks_isotope_'.esc_attr($rand_id).'">';
						echo '<ul>';
							echo '<li data-filter="*" class="active"><a href="#">' . __('All', 'arexworks-plugin') . '</a></li>';
							if ( !empty ( $category__in ) ) {
								foreach ( $category__in as $cat_id ){
									$category_object = get_term( $cat_id, 'category' );
									if ( is_wp_error($category_object) )
										continue;
									echo '<li data-filter="category-' . esc_attr( $category_object->slug ) . '"><a href="#">' . esc_html($category_object->name) . '</a></li>';
								}
							}
						echo '</ul>';
					echo '</div>';
				}
				echo '<div id="arexworks_isotope_'.esc_attr($rand_id).'" class="'.esc_attr($class_block_grid).'">';
			}
			while ($the_query->have_posts()) {
				$the_query->the_post();
				get_template_part( 'template-shares/loop/content', $post_layout );
			}
			if( $post_layout == 'slide' || $post_layout == 'slide2'){
				echo '</div>';
			}
			if( $post_layout == 'grid' ){
				echo '</div>';
			}
			if( $post_layout == 'isotope' ){
				echo '<div class="arexworks-isotope-loading"><div></div></div>';
				echo '</div>';
				echo '</div>';
			}
			?>
		</div>
	</div>
	<?php
	$output .= ob_get_clean();

	if ( $view_more ){
		$view_more_link_object = arexworks_parse_multi_attribute( $view_more_link, array( 'url' => '#', 'title' => '', 'target' => '_self' ) );
		$output .= '<div class="view-more-posts">';
		$output .= '<a class="button"';
		$output .= 'href="' . esc_url($view_more_link_object['url']) . '" ';
		$output .= 'title="' . esc_attr($view_more_link_object['title']) . '" ';
		$output .= 'target="' . esc_attr($view_more_link_object['target']) . '" ';
		$output .= 'data-query="'.esc_attr( json_encode($args) ).'" ';
		$output .= 'data-paged="1" ';
		$output .= 'data-arexworks_loop="' . esc_attr( json_encode($arexworks_loop) ) . '" ';
		$output .= '>';
		$output .= esc_html( $view_more_link_object['title'] );
		$output .= '</a>';
		$output .= '</div>';
	}
	$output .= '</div>' . arexworks_shortcode_end_block_comment( 'arexworks_show_posts' ) . "\n";
	echo $output;
}

$arexworks_loop = array();
wp_reset_postdata();
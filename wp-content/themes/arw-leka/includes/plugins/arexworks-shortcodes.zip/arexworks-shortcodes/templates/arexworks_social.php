<?php
$title = $facebook_link = $twitter_link = $pinterest_link = $linkedin_link = $googleplus_link = $rss_link = $tumblr_link = $instagram_link = $youtube_link = $vimeo_link = $behance_link = $dribble_link = $flickr_link = $git_link = $skype_link = $weibo_link = $foursquare_link = $soundcloud_link = $el_class = '';
$output = '';

$default_atts = array(
	'title' => '',
	'facebook_link' => '',
	'twitter_link' => '',
	'pinterest_link' => '',
	'linkedin_link' => '',
	'googleplus_link' => '',
	'rss_link' => '',
	'tumblr_link' => '',
	'instagram_link' => '',
	'youtube_link' => '',
	'vimeo_link' => '',
	'behance_link' => '',
	'dribble_link' => '',
	'flickr_link' => '',
	'git_link' => '',
	'skype_link' => '',
	'weibo_link' => '',
	'foursquare_link' => '',
	'soundcloud_link' => '',
	'el_class' => '',
);

global $arexworks_theme_options;

$default_atts = shortcode_atts($default_atts,$arexworks_theme_options);

extract(shortcode_atts($default_atts, $atts));

$array_value = array(
	'facebook_link' => array(
		'label' => __('Facebook','arexworks-plugin'),
		'icon'  => 'fa fa-facebook',
		'url'   => esc_url($facebook_link)
	),
	'twitter_link' => array(
		'label' => __('Twitter','arexworks-plugin'),
		'icon'  => 'fa fa-twitter',
		'url'   => esc_url($twitter_link)
	),
	'pinterest_link' => array(
		'label' => __('Pinterest','arexworks-plugin'),
		'icon'  => 'fa fa-pinterest',
		'url'   => esc_url($pinterest_link)
	),
	'linkedin_link' => array(
		'label' => __('LinkedIn','arexworks-plugin'),
		'icon'  => 'fa fa-linkedin',
		'url'   => esc_url($linkedin_link)
	),
	'googleplus_link' => array(
		'label' => __('Google+','arexworks-plugin'),
		'icon'  => 'fa fa-google-plus',
		'url'   => esc_url($googleplus_link)
	),
	'rss_link' => array(
		'label' => __('Rss','arexworks-plugin'),
		'icon'  => 'fa fa-rss',
		'url'   => esc_url($rss_link)
	),
	'tumblr_link' => array(
		'label' => __('Tumblr','arexworks-plugin'),
		'icon'  => 'fa fa-tumblr',
		'url'   => esc_url($tumblr_link)
	),
	'instagram_link' => array(
		'label' => __('Instagram','arexworks-plugin'),
		'icon'  => 'fa fa-instagram',
		'url'   => esc_url($instagram_link)
	),
	'youtube_link' => array(
		'label' => __('Youtube','arexworks-plugin'),
		'icon'  => 'fa fa-youtube-play',
		'url'   => esc_url($youtube_link)
	),
	'vimeo_link' => array(
		'label' => __('Vimeo','arexworks-plugin'),
		'icon'  => 'fa fa-vimeo',
		'url'   => esc_url($vimeo_link)
	),
	'behance_link' => array(
		'label' => __('Behance','arexworks-plugin'),
		'icon'  => 'fa fa-behance',
		'url'   => esc_url($behance_link)
	),
	'dribble_link' => array(
		'label' => __('Dribbble','arexworks-plugin'),
		'icon'  => 'fa fa-dribbble',
		'url'   => esc_url($dribble_link)
	),
	'flickr_link' => array(
		'label' => __('Flickr','arexworks-plugin'),
		'icon'  => 'fa fa-flickr',
		'url'   => esc_url($flickr_link)
	),
	'git_link' => array(
		'label' => __('Git','arexworks-plugin'),
		'icon'  => 'fa fa-git',
		'url'   => esc_url($git_link)
	),
	'skype_link' => array(
		'label' => __('Skype','arexworks-plugin'),
		'icon'  => 'fa fa-skype',
		'url'   => esc_url($skype_link)
	),
	'weibo_link' => array(
		'label' => __('Weibo','arexworks-plugin'),
		'icon'  => 'fa fa-weibo',
		'url'   => esc_url($weibo_link)
	),
	'foursquare_link' => array(
		'label' => __('Foursquare','arexworks-plugin'),
		'icon'  => 'fa fa-foursquare',
		'url'   => esc_url($foursquare_link)
	),
	'soundcloud_link'=> array(
		'label' => __('Soundcloud','arexworks-plugin'),
		'icon'  => 'fa fa-soundcloud',
		'url'   => esc_url($soundcloud_link)
	),
);

$el_class = arexworks_shortcode_extract_class( $el_class );

$output .= '<div class="arexworks-social wpb_content_element '. esc_attr($el_class) . '" >';
	$output .= arexworks_shortcode_vc_widget_title(array('title'=>$title));
	$output .= '<ul>';
		foreach ( $array_value as $key => $value ){
			if(isset($$key) && !empty($$key)){
				$output .= sprintf(
					'<li><a href="%s" target="_blank" title="%s"><i class="%s"></i><span>%s</span></a></li>',
					$value['url'],
					esc_html($value['label']),
					esc_attr($value['icon']),
					esc_html($value['label'])
				);
			}
		}
	$output .= '</ul>';
$output .= '</div>'.arexworks_shortcode_end_block_comment( 'arexworks_social' );

echo $output;
<?php
$output = $name = $role = $company = $author_url = $photo_url = $photo_id = $quote = $style = $el_class = '';
extract(shortcode_atts(array(
    'name' => '',
    'role' => '',
    'company' => '',
    'author_url' => '',
    'photo_url' => '',
    'photo_id' => '',
    'quote' => '',
    'style' => 'style-1',
    'el_class' => '',
), $atts));

$el_class = arexworks_shortcode_extract_class( $el_class );

$el_class .= ' testimonial-'.$style;

if (!$photo_url && $photo_id)
    $photo_url = wp_get_attachment_url($photo_id);

$porto_url = str_replace(array('http:', 'https:'), '', $photo_url);

$output = '<div class="arexworks-testimonial wpb_content_element '. $el_class . '"';
$output .= '>';
	switch($style){
		case 'style-3':
			$output .= '<div class="testimonial">';
			$output .= '<div class="testimonial-author-thumbnail-wrapper">';
			if ($photo_url) {
				$output .= '<img class="testimonial-author-thumbnail" src="'.esc_url($photo_url).'" alt="' . $name . '">';
			}
			$output .= '</div>';
			$output .= '<div class="testimonial-content">';
			$output .= do_shortcode($content != '' ? $content : $quote);
			$output .= '</div>';
			$output .= '<div class="testimonial-arrow"><span></span></div>';
			$output .= '<div class="testimonial-author clearfix">';
			$output .= '<p>';
			if ($author_url) {
				$output .= '<a href="'.esc_url($author_url).'">';
			}
			$output .= '<strong>'.$name.'</strong>';
			if ($author_url) {
				$output .= '</a>';
			}
			$output .= '<span>'.$role.(($role && $company)?' <i></i> ':'').$company.'</span></p>';
			$output .= '</div>';
			$output .= '</div>';
			break;
		case 'style-2':
			$output .= '<div class="testimonial">';
			$output .= '<div class="testimonial-author-thumbnail-wrapper">';
			if ($photo_url) {
				$output .= '<img class="testimonial-author-thumbnail" src="'.esc_url($photo_url).'" alt="' . $name . '">';
			}
			$output .= '</div>';
			$output .= '<div class="testimonial-content">';
			$output .= do_shortcode($content != '' ? $content : $quote);
			$output .= '</div>';
			$output .= '<div class="testimonial-arrow"><span></span></div>';
			$output .= '<div class="testimonial-author clearfix">';
			$output .= '<p>';
			if ($author_url) {
				$output .= '<a href="'.esc_url($author_url).'">';
			}
			$output .= '<strong>'.$name.'</strong>';
			if ($author_url) {
				$output .= '</a>';
			}
			$output .= '<span>'.$role.(($role && $company)?' <i></i> ':'').$company.'</span></p>';
			$output .= '</div>';
			$output .= '</div>';
			break;
		default:
			$output .= '<div class="testimonial">';
				$output .= '<div class="testimonial-content">';
					$output .= do_shortcode($content != '' ? $content : $quote);
				$output .= '</div>';
				$output .= '<div class="testimonial-arrow"><span></span></div>';
				$output .= '<div class="testimonial-author clearfix">';
					$output .= '<div class="testimonial-author-thumbnail-wrapper">';
					if ($photo_url) {
						$output .= '<img class="testimonial-author-thumbnail" src="'.esc_url($photo_url).'" alt="' . $name . '">';
					}
					$output .= '</div><p>';
					if ($author_url) {
						$output .= '<a href="'.esc_url($author_url).'">';
					}
					$output .= '<strong>'.$name.'</strong>';
					if ($author_url) {
						$output .= '</a>';
					}
					$output .= '<span>'.$role.(($role && $company)?' <i></i> ':'').$company.'</span></p>';
				$output .= '</div>';
			$output .= '</div>';
	}

$output .= '</div>' . arexworks_shortcode_end_block_comment( 'arexworks_testimonial' ) . "\n";;

echo $output;
<?php
add_shortcode('arexworks_register_page', 'arexworks_shortcode_arexworks_register_page');

if ( !function_exists( 'arexworks_shortcode_arexworks_register_page' ) ) {
	function arexworks_shortcode_arexworks_register_page($atts, $content = null) {
		$output = apply_filters('arexworks_register_page_shortcode_filter', '', $atts, $content);
		if ( $output != ''){
			return $output;
		}
		ob_start();
		if ($template = arexworks_shortcode_woo_template('arexworks_register_page'))
			include $template;
		return ob_get_clean();
	}
}
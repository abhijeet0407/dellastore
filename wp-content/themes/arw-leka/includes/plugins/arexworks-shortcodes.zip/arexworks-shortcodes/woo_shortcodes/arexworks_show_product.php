<?php
add_shortcode('arexworks_show_product', 'arexworks_shortcode_arexworks_show_product');
add_action('vc_after_init', 'arexworks_load_arexworks_show_product_shortcode');

add_filter( 'vc_autocomplete_arexworks_show_product_category_id_callback', 'arexworks_add_filter_vc_product_category_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_product_category_id_render', 'arexworks_add_filter_vc_product_category_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_product_category_ids_callback', 'arexworks_add_filter_vc_product_category_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_product_category_ids_render', 'arexworks_add_filter_vc_product_category_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_product_exclude_callback', 'arexworks_add_filter_vc_product_id_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_product_exclude_render', 'arexworks_add_filter_vc_product_id_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_product_product_ids_callback', 'arexworks_add_filter_vc_product_id_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_product_product_ids_render', 'arexworks_add_filter_vc_product_id_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_product_brand_id_callback', 'arexworks_add_filter_vc_product_brand_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_product_brand_id_render', 'arexworks_add_filter_vc_product_brand_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_show_product_brand_ids_callback', 'arexworks_add_filter_vc_product_brand_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_show_product_brand_ids_render', 'arexworks_add_filter_vc_product_brand_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_product_brand_logo_exclude_callback', 'arexworks_product_brand_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_product_brand_logo_exclude_render', 'arexworks_add_filter_vc_product_brand_renderByIdExact', 10, 1 );

add_filter( 'vc_autocomplete_arexworks_product_brand_logo_include_callback', 'arexworks_add_filter_vc_product_brand_autocomplete_suggester', 10, 1 );
add_filter( 'vc_autocomplete_arexworks_product_brand_logo_include_render', 'arexworks_add_filter_vc_product_brand_renderByIdExact', 10, 1 );

if ( !function_exists( 'arexworks_shortcode_arexworks_show_product' ) ) {
	function arexworks_shortcode_arexworks_show_product($atts, $content = null) {
		$output = apply_filters('arexworks_show_product_shortcode_filter', '', $atts, $content);
		if ( $output != ''){
			return $output;
		}
		ob_start();
		if ($template = arexworks_shortcode_woo_template('arexworks_show_product'))
			include $template;
		return ob_get_clean();
	}
}

if ( !function_exists( 'arexworks_load_arexworks_show_product_shortcode' ) ){
	function arexworks_load_arexworks_show_product_shortcode(){
		$woo_orderby = arexworks_shortcode_vc_woo_order_by();
		$woo_order = arexworks_shortcode_vc_woo_order_way();
		vc_map(
			array(
				"name"		=> __("Arexworks Show Product", 'arexworks-plugin'),
				"base"		=> "arexworks_show_product",
				"icon"		=> "icon-wpb-woocommerce",
				"class"	   => "arexworks_show_product",
				"category"  => __("Arexworks", 'arexworks-plugin'),
				"description" => __("Display products",'arexworks-plugin'),
				"controls" => "full",
				"show_settings_on_create" => true,
				"params" => array(
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Title", 'arexworks-plugin' ),
						"param_name" => "title",
						"group" => __("Initial Settings",'arexworks-plugin')
					),

					array(
						"type" => "dropdown",
						"class" => "",
						"heading" => __( "Display", 'arexworks-plugin' ),
						"param_name" => "display_type",
						'value' => array(
							__("Recent products",'arexworks-plugin') => "recent_products",
							__("Featured Products",'arexworks-plugin') => "featured_products",
							__("Top Rated Products",'arexworks-plugin') => "top_rated_products",
							__("Product Category",'arexworks-plugin') => "product_category",
							__("Product Categories",'arexworks-plugin') => "product_categories",
							__("By brand",'arexworks-plugin') => "product_brand",
							__("By list brands",'arexworks-plugin') => "product_brands",
							__("Products on Sale",'arexworks-plugin') => "sale_products",
							__("Best Selling Products",'arexworks-plugin') => "best_selling_products",
						),
						"group" => __("Initial Settings",'arexworks-plugin'),
						'admin_label' => true,
					),
					array(
						'type' => 'autocomplete',
						'heading' => __( 'Category:', 'arexworks-plugin' ),
						'param_name' => 'category_id',
						'settings' => array(
							'unique_values' => true,
							'multiple' => false,
							'sortable' => false,
							'groups' => false,
							'min_length' => 0,
							'auto_focus' => true,
							'display_inline' => true, // In UI show results inline view
						),
						'dependency' => array(
							'element' => 'display_type',
							'value' => array( 'product_category' )
						),
						"group" => __("Initial Settings",'arexworks-plugin')
					),
					array(
						'type' => 'autocomplete',
						'heading' => __( 'Categories:', 'arexworks-plugin' ),
						'param_name' => 'category_ids',
						'settings' => array(
							'unique_values' => true,
							'multiple' => true,
							'sortable' => true,
							'groups' => false,
							'min_length' => 0,
							'auto_focus' => true,
							'display_inline' => true, // In UI show results inline view
						),
						'dependency' => array(
							'element' => 'display_type',
							'value' => array( 'product_categories' )
						),
						"group" => __("Initial Settings",'arexworks-plugin')
					),

					array(
						'type' => 'autocomplete',
						'heading' => __( 'Brand:', 'arexworks-plugin' ),
						'param_name' => 'brand_id',
						'settings' => array(
							'unique_values' => true,
							'multiple' => false,
							'sortable' => false,
							'groups' => false,
							'min_length' => 0,
							'auto_focus' => true,
							'display_inline' => true, // In UI show results inline view
						),
						'dependency' => array(
							'element' => 'display_type',
							'value' => array( 'product_brand' )
						),
						"group" => __("Initial Settings",'arexworks-plugin')
					),
					array(
						'type' => 'autocomplete',
						'heading' => __( 'Brands:', 'arexworks-plugin' ),
						'param_name' => 'brand_ids',
						'settings' => array(
							'unique_values' => true,
							'multiple' => true,
							'sortable' => true,
							'groups' => false,
							'min_length' => 0,
							'auto_focus' => true,
							'display_inline' => true, // In UI show results inline view
						),
						'dependency' => array(
							'element' => 'display_type',
							'value' => array( 'product_brands' )
						),
						"group" => __("Initial Settings",'arexworks-plugin')
					),

					array(
						'type' => 'autocomplete',
						'heading' => __( 'Product Exclude:', 'arexworks-plugin' ),
						'param_name' => 'exclude',
						'settings' => array(
							'unique_values' => true,
							'multiple' => true,
							'groups' => false,
							'min_length' => 0,
							'auto_focus' => true,
							'display_inline' => true
						),
						"group" => __("Initial Settings",'arexworks-plugin')
					),
					array(
						'type' => 'autocomplete',
						'heading' => __( 'Product Include:', 'arexworks-plugin' ),
						'param_name' => 'product_ids',
						'settings' => array(
							'unique_values' => true,
							'multiple' => true,
							'groups' => false,
							'min_length' => 0,
							'auto_focus' => true,
							'display_inline' => true
						),
						"group" => __("Initial Settings",'arexworks-plugin')
					),
					array(
						"type" => "dropdown",
						"class" => "",
						"heading" => __( "Order By:", 'arexworks-plugin' ),
						"param_name" => "orderby",
						"value" => $woo_orderby ,
						"group" => __("Initial Settings",'arexworks-plugin')
					),
					array(
						"type" => "dropdown",
						"class" => "",
						"heading" => __( "Display Order:", 'arexworks-plugin' ),
						"param_name" => "order",
						'value' => $woo_order,
						"group" => __("Initial Settings",'arexworks-plugin')
					),
					// Display Settings
					array(
						"type" => "dropdown",
						"class" => "",
						"heading" => __( "Style:", 'arexworks-plugin' ),
						"param_name" => "style",
						'value' => array(
							__("Grid Mode",'arexworks-plugin') => "grid",
							__("Grid Mode 2",'arexworks-plugin') => "grid2",
							__("List Mode",'arexworks-plugin') => "list",
							__("List Mode Large",'arexworks-plugin') => "list2",
							__("List Mode Mini",'arexworks-plugin') => "list-mini",
						),
						"group" => __("Display Settings",'arexworks-plugin'),
						'admin_label' => true,
					),
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "How Many:", 'arexworks-plugin' ),
						"description" => __( "",'arexworks-plugin' ),
						"param_name" => "per_page",
						"value" => 12,
						"group" => __("Display Settings",'arexworks-plugin')
					),
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Columns:", 'arexworks-plugin' ),
						"description" => __( "Product in per row (1024px or larger)",'arexworks-plugin' ),
						"param_name" => "columns",
						"value" => 4,
						"dependency" => array(
							"element" => "style",
							"value" => array( "grid" , "grid2" ),
						),
						"group" => __("Display Settings",'arexworks-plugin')
					),
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Columns in Tablet:", 'arexworks-plugin' ),
						"description" => __( "Product in per row (640px to 1024px)",'arexworks-plugin' ),
						"param_name" => "medium_columns",
						"value" => 3,
						"dependency" => array(
							"element" => "style",
							"value" => array( "grid" , "grid2" ),
						),
						"group" => __("Display Settings",'arexworks-plugin')
					),
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Columns in Mobile:", 'arexworks-plugin' ),
						"description" => __( "Product in per row ( < 640px)",'arexworks-plugin' ),
						"param_name" => "small_columns",
						"value" => 2,
						"dependency" => array(
							"element" => "style",
							"value" => array( "grid" , "grid2" ),
						),
						"group" => __("Display Settings",'arexworks-plugin')
					),

					array(
						'type' => 'checkbox',
						'heading' => __( 'Enable Carousel ?', 'arexworks-plugin' ),
						'param_name' => 'enable_carousel',
						'description' => __( '', 'arexworks-plugin' ),
						'value' => array( __( 'Yes', 'arexworks-plugin' ) => 'yes' ),
						"group" => __("Display Settings",'arexworks-plugin'),
						'admin_label' => true,
					),
					array(
						"type" => "number",
						"class" => "",
						"heading" => __("Number of Slides to Scroll", 'arexworks-plugin'),
						"param_name" => "slides_to_scroll",
						"value" => "1",
						"min" => 1,
						"max" => 6,
						'dependency' => array(
							'element' => 'enable_carousel',
							'value' => array( 'yes' ),
						),
						"description" => __("The number of slides to move on transition",'arexworks-plugin'),
						"group" => __("Display Settings",'arexworks-plugin'),
					),
					array(
						"type" => "number",
						"class" => "",
						"heading" => __("Slide Scrolling Speed", 'arexworks-plugin'),
						"param_name" => "scroll_speed",
						"value" => "1000",
						"min" => 100,
						"max" => 10000,
						"suffix" => "ms",
						"description" => __("Slide transition duration (in ms)", 'arexworks-plugin'),
						'dependency' => array(
							'element' => 'enable_carousel',
							'value' => array( 'yes' ),
						),
						"group" => __("Display Settings",'arexworks-plugin')
					),
					array(
						"type" => "checkbox",
						"class" => "",
						"heading" => __("Advanced settings -", 'arexworks-plugin'),
						"param_name" => "advanced_opts",
						"value" => array(
							__("Enable infinite scroll",'arexworks-plugin')."<br>" => "infinite",
							__("Enable dots",'arexworks-plugin')."<br>" => "dots",
							__("Enable navigation",'arexworks-plugin')."<br>" => "navs",
							__("Enable auto play",'arexworks-plugin')."<br>" => "autoplay",
						),
						'dependency' => array(
							'element' => 'enable_carousel',
							'value' => array( 'yes' ),
						),
						"group" => __("Display Settings",'arexworks-plugin'),
					),
					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Custom Navigation Carousel Element", 'arexworks-plugin' ),
						"param_name" => "custom_nav_carousel",
						"description" => "Ex: jQuery('.{class_name}') or jQuery(#{id_name})",
						"value" => "",
						'dependency' => array(
							'element' => 'enable_carousel',
							'value' => array( 'yes' ),
						),
						"group" => __("Display Settings",'arexworks-plugin')
					),
					array(
						"type" => "number",
						"class" => "",
						"heading" => __("AutoPlay Speed", 'arexworks-plugin'),
						"param_name" => "autoplay_speed",
						"value" => 500,
						"min" => 100,
						"max" => 10000,
						"suffix" => "ms",
						"description" => __("Slide transition duration (in ms)", 'arexworks-plugin'),
						'dependency' => array(
							'element' => 'enable_carousel',
							'value' => array( 'yes' ),
						),
						"group" => __("Display Settings",'arexworks-plugin')
					),

					array(
						"type" => "textfield",
						"class" => "",
						"heading" => __( "Extra Class:", 'arexworks-plugin' ),
						"param_name" => "el_class",
						"value" => "",
						"group" => __("Display Settings",'arexworks-plugin')
					),
				)
			)
		);
		if (!class_exists('WPBakeryShortCode_Arexworks_Show_Product')) {
			class WPBakeryShortCode_Arexworks_Show_Product extends WPBakeryShortCode {
			}
		}
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_product_category_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_product_category_autocomplete_suggester( $query, $slug = false )
	{
		global $wpdb;
		$cat_id = (int) $query;
		$query = trim( $query );
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = 'product_cat' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )",
				$cat_id > 0 ? $cat_id : -1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

		$result = array();
		if ( is_array( $post_meta_infos ) && !empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data[ 'value' ] = $slug ? $value[ 'slug' ] : $value[ 'id' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'name' ] ) > 0 ) ? ' - ' . __( 'Name', 'js_composer' ) . ': ' .
						$value[ 'name' ] : '' ) .
					( ( strlen( $value[ 'slug' ] ) > 0 ) ? ' - ' . __( 'Slug', 'js_composer' ) . ': ' .
						$value[ 'slug' ] : '' );
				$result[ ] = $data;
			}
		}

		return $result;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_product_category_renderByIdExact' ) ) {
	function arexworks_add_filter_vc_product_category_renderByIdExact( $query )
	{

		$query = $query[ 'value' ];
		$cat_id = (int) $query;
		$term = get_term( $cat_id, 'product_cat' );

		$term_slug = $term->slug;
		$term_title = $term->name;
		$term_id = $term->term_id;

		$term_slug_display = '';
		if ( !empty( $term_slug ) ) {
			$term_slug_display = ' - ' . __( 'Slug', 'js_composer' ) . ': ' . $term_slug;
		}

		$term_title_display = '';
		if ( !empty( $term_title ) ) {
			$term_title_display = ' - ' . __( 'Title', 'js_composer' ) . ': ' . $term_title;
		}

		$term_id_display = __( 'Id', 'js_composer' ) . ': ' . $term_id;

		$data = array();
		$data[ 'value' ] = $term_id;
		$data[ 'label' ] = $term_id_display . $term_title_display . $term_slug_display;

		return !empty( $data ) ? $data : false;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_product_brand_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_product_brand_autocomplete_suggester( $query, $slug = false )
	{
		global $wpdb;
		$cat_id = (int) $query;
		$query = trim( $query );
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.term_id AS id, b.name as name, b.slug AS slug
						FROM {$wpdb->term_taxonomy} AS a
						INNER JOIN {$wpdb->terms} AS b ON b.term_id = a.term_id
						WHERE a.taxonomy = 'product_brand' AND (a.term_id = '%d' OR b.slug LIKE '%%%s%%' OR b.name LIKE '%%%s%%' )",
				$cat_id > 0 ? $cat_id : -1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

		$result = array();
		if ( is_array( $post_meta_infos ) && !empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data[ 'value' ] = $slug ? $value[ 'slug' ] : $value[ 'id' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'name' ] ) > 0 ) ? ' - ' . __( 'Name', 'js_composer' ) . ': ' .
						$value[ 'name' ] : '' ) .
					( ( strlen( $value[ 'slug' ] ) > 0 ) ? ' - ' . __( 'Slug', 'js_composer' ) . ': ' .
						$value[ 'slug' ] : '' );
				$result[ ] = $data;
			}
		}

		return $result;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_product_brand_renderByIdExact' ) ) {
	function arexworks_add_filter_vc_product_brand_renderByIdExact( $query )
	{
		global $wpdb;
		$query = $query[ 'value' ];
		$cat_id = (int) $query;
		$term = get_term( $cat_id, 'product_brand' );

		$term_slug = $term->slug;
		$term_title = $term->name;
		$term_id = $term->term_id;

		$term_slug_display = '';
		if ( !empty( $term_slug ) ) {
			$term_slug_display = ' - ' . __( 'Slug', 'js_composer' ) . ': ' . $term_slug;
		}

		$term_title_display = '';
		if ( !empty( $term_id ) ) {
			$term_title_display = ' - ' . __( 'Title', 'js_composer' ) . ': ' . $term_title;
		}

		$term_id_display = __( 'Id', 'js_composer' ) . ': ' . $term_id;

		$data = array();
		$data[ 'value' ] = $term_id;
		$data[ 'label' ] = $term_id_display . $term_title_display . $term_slug_display;

		return !empty( $data ) ? $data : false;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_product_id_autocomplete_suggester' ) ) {
	function arexworks_add_filter_vc_product_id_autocomplete_suggester( $query )
	{
		global $wpdb;
		$product_id = (int) $query;
		$post_meta_infos = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT a.ID AS id, a.post_title AS title, b.meta_value AS sku
					FROM {$wpdb->posts} AS a
					LEFT JOIN ( SELECT meta_value, post_id  FROM {$wpdb->postmeta} WHERE `meta_key` = '_sku' ) AS b ON b.post_id = a.ID
					WHERE a.post_type = 'product' AND ( a.ID = '%d' OR b.meta_value LIKE '%%%s%%' OR a.post_title LIKE '%%%s%%' )",
				$product_id > 0 ? $product_id : -1, stripslashes( $query ), stripslashes( $query ) ), ARRAY_A );

		$results = array();
		if ( is_array( $post_meta_infos ) && !empty( $post_meta_infos ) ) {
			foreach ( $post_meta_infos as $value ) {
				$data = array();
				$data[ 'value' ] = $value[ 'id' ];
				$data[ 'label' ] = __( 'Id', 'js_composer' ) . ': ' .
					$value[ 'id' ] .
					( ( strlen( $value[ 'title' ] ) > 0 ) ? ' - ' . __( 'Title', 'js_composer' ) . ': ' .
						$value[ 'title' ] : '' ) .
					( ( strlen( $value[ 'sku' ] ) > 0 ) ? ' - ' . __( 'Sku', 'js_composer' ) . ': ' .
						$value[ 'sku' ] : '' );
				$results[ ] = $data;
			}
		}

		return $results;
	}
}

if ( !function_exists( 'arexworks_add_filter_vc_product_id_renderByIdExact' ) ) {
	function arexworks_add_filter_vc_product_id_renderByIdExact( $query )
	{
		$query = trim( $query[ 'value' ] ); // get value from requested
		if ( !empty( $query ) ) {
			// get product
			$product_object = wc_get_product( (int) $query );
			if ( is_object( $product_object ) ) {
				$product_sku = $product_object->get_sku();
				$product_title = $product_object->get_title();
				$product_id = $product_object->id;

				$product_sku_display = '';
				if ( !empty( $product_sku ) ) {
					$product_sku_display = ' - ' . __( 'Sku', 'js_composer' ) . ': ' . $product_sku;
				}

				$product_title_display = '';
				if ( !empty( $product_title ) ) {
					$product_title_display = ' - ' . __( 'Title', 'js_composer' ) . ': ' . $product_title;
				}

				$product_id_display = __( 'Id', 'js_composer' ) . ': ' . $product_id;

				$data = array();
				$data[ 'value' ] = $product_id;
				$data[ 'label' ] = $product_id_display . $product_title_display . $product_sku_display;

				return !empty( $data ) ? $data : false;
			}

			return false;
		}

		return false;
	}
}
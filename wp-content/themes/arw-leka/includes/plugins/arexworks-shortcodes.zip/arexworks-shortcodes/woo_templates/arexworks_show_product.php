<?php
global $woocommerce , $woocommerce_loop;
$uid = uniqid();
$brand_ids = $brand_id = '';
$title = $display_type = $order = $orderby = $alt_image = $per_page = $columns = $medium_columns = $small_columns = $exclude = $product_ids = $category_ids = $category_id = $style = '';
$enable_carousel = $slides_to_scroll = $scroll_speed = $advanced_opts = $autoplay_speed = $custom_nav_carousel = $el_class = '';
extract(shortcode_atts(array(
	                       'title' => '',
	                       'display_type' => 'recent_products',
	                       'order' => 'asc',
	                       'orderby' => 'date',
	                       'alt_image' => 1,
	                       'per_page' => 12,
	                       'columns' => 4,
	                       'medium_columns' => 3,
	                       'small_columns' => 2,
	                       'exclude' => '',
	                       'product_ids' => '',
	                       'category_ids' => '',
	                       'category_id' => '',
	                       'brand_ids' => '',
	                       'brand_id' => '',
	                       'style' => 'grid',
	                       'enable_carousel' => false,
	                       'slides_to_scroll' => 1,
	                       'scroll_speed' => 1000,
	                       'advanced_opts' => '',
	                       'autoplay_speed' => 500,
	                       'custom_nav_carousel' => '',
	                       'el_class' => ''
                       ), $atts));

$el_class = arexworks_shortcode_extract_class( $el_class );

if($product_ids){
	$product_ids = explode( ',', $product_ids );
	$product_ids = array_map( 'trim', $product_ids );
}
if($exclude){
	$exclude = explode( ',', $exclude );
	$exclude = array_map( 'trim', $exclude );
}
if($category_ids){
	$category_ids = explode( ',', $category_ids );
	$category_ids = array_map( 'trim', $category_ids );
}
if($brand_ids){
	$brand_ids = explode( ',', $brand_ids );
	$brand_ids = array_map( 'trim', $brand_ids );
}
$paged = 1;

$meta_query = '';
if($display_type == "recent_products"){
	$meta_query = WC()->query->get_meta_query();
}

if($display_type == "featured_products"){
	$meta_query = array(
		array(
			'key' 		=> '_visibility',
			'value' 	  => array('catalog', 'visible'),
			'compare'	=> 'IN'
		),
		array(
			'key' 		=> '_featured',
			'value' 	  => 'yes'
		)
	);
}

if($display_type == "top_rated_products"){
	add_filter( 'posts_clauses',  array( WC()->query, 'order_by_rating_post_clauses' ) );
	$meta_query = WC()->query->get_meta_query();
}
$args = array(
	'post_type'			    => 'product',
	'post_status'		    => 'publish',
	'ignore_sticky_posts'   => 1,
	'posts_per_page' 	    => $per_page,
	'orderby' 			    => $orderby,
	'order' 				=> $order,
	'paged' 				=> $paged,
	'meta_query' 		    => $meta_query
);
if($display_type == "sale_products"){
	$product_ids_on_sale = wc_get_product_ids_on_sale();
	$meta_query = array();
	$meta_query[] = $woocommerce->query->visibility_meta_query();
	$meta_query[] = $woocommerce->query->stock_status_meta_query();
	$args['meta_query'] = $meta_query;
	$args['post__in'] = $product_ids_on_sale;
}
if($display_type == "best_selling_products"){
	$args['meta_key'] = 'total_sales';
	$args['orderby'] = 'meta_value_num';
	$args['meta_query'] = array(
		array(
			'key' 		=> '_visibility',
			'value' 	=> array( 'catalog', 'visible' ),
			'compare' 	=> 'IN'
		)
	);
}
if($display_type == "product_category"){
	$args['tax_query'] = array(
		array(
			'taxonomy' 	 => 'product_cat',
			'terms' 		=> array( esc_attr($category_id) ),
			'field' 		=> 'term_id',
			'operator' 	 => 'IN'
		)
	);
}
if($display_type == "product_categories"){
	$args['tax_query'] = array(
		array(
			'taxonomy' 	 => 'product_cat',
			'terms' 		=> $category_ids,
			'field' 		=> 'term_id',
			'operator' 	 => 'IN'
		)
	);
}

if($display_type == "product_brand"){
	$args['tax_query'] = array(
		array(
			'taxonomy' 	 => 'product_brand',
			'terms' 		=> array( esc_attr($brand_id) ),
			'field' 		=> 'term_id',
			'operator' 	 => 'IN'
		)
	);
}
if($display_type == "product_brands"){
	$args['tax_query'] = array(
		array(
			'taxonomy' 	 => 'product_brand',
			'terms' 		=> $brand_ids,
			'field' 		=> 'term_id',
			'operator' 	 => 'IN'
		)
	);
}

if(!empty($exclude)){
	$args['post__not_in']  = $exclude;
}
if(!empty($product_ids)){
	if(isset($args['post__in'])){
		$args_post__in = $args['post__in'];
		if(is_array($product_ids)){
			foreach($product_ids as $val){
				$args_post__in[] = $val;
			}
		}
	}else{
		$args_post__in = $product_ids;
	}
	$args['post__in'] = $args_post__in;
};

$woocommerce_loop['mode_view'] = $style;

$class_wrapper = "products small-block-grid-$small_columns medium-block-grid-$medium_columns large-block-grid-$columns";
if($style == 'list') {
	$class_wrapper = "products small-block-grid-1";
	$class_wrapper_extra = 'products-list';
}elseif($style == 'list-mini'){
	$class_wrapper = "products";
	$class_wrapper_extra = 'products-list-mini';
}elseif($style == 'list2'){
	$class_wrapper = "products small-block-grid-1";
	$class_wrapper_extra = 'products-list2';
}elseif($style == 'grid2'){
	$class_wrapper_extra = 'products-grid products-grid2';
}else{
	$class_wrapper_extra = 'products-grid';
}

$show_navs = $infinite = $autoplay = $dots = false;
$advanced_opts = explode(",", $advanced_opts);


if(in_array("infinite",$advanced_opts)){
	$infinite = true;
}
if(in_array("autoplay",$advanced_opts)){
	$autoplay = true;
}
if(in_array("dots",$advanced_opts)){
	$dots = true;
}
if(in_array("navs",$advanced_opts)){
	$show_navs = true;
}

if($enable_carousel){
	$class_wrapper = 'arexworks-slick-slider products product-carousel '. $class_wrapper_extra;

	$slider_config = array(
		'infinite' => $infinite,
		'slidesToShow' => intval($columns),
		'slidesToScroll' => intval($slides_to_scroll),
		'dots' => $dots,
		'autoplay' => $autoplay,
		'arrows' => $show_navs,
		'speed' => intval($scroll_speed),
		'autoplaySpeed' => intval($autoplay_speed),
		'centerPadding' => 0,
		'slide' => 'ul',
		'responsive' => array(
			array(
				'breakpoint' => 1440,
				'settings' => array(
					'slidesToShow' => intval($columns),
					'slidesToScroll' => intval($slides_to_scroll),
					'slide' => 'ul'
				)
			),
			array(
				'breakpoint' => 992,
				'settings' => array(
					'slidesToShow' => intval($medium_columns),
					'slidesToScroll' => intval($medium_columns),
					'slide' => 'ul'
				)
			),
			array(
				'breakpoint' => 768,
				'settings' => array(
					'slidesToShow' => intval($small_columns),
					'slidesToScroll' => intval($small_columns),
					'slide' => 'ul'
				)
			),
			array(
				'breakpoint' => 480,
				'settings' => array(
					'slidesToShow' => 1,
					'slidesToScroll' => 1,
					'slide' => 'ul'
				)
			)
		)
	);
	if(!empty($custom_nav_carousel)){
		$slider_config['appendArrows'] = 'jQuery("'.esc_attr($custom_nav_carousel).'")';
	}

	$open_tag = "<div data-slider_config=\"".esc_attr(json_encode($slider_config))."\" class=\"{$class_wrapper}\" id=\"product_carousel_{$uid}\">";
	$open_tag_inner = "<ul class=\"slick-inner-item\">";
	$close_tag = '</div>';
	$close_tag_inner = "</ul>";
}else{
	$open_tag = "<ul class=\"{$class_wrapper} {$class_wrapper_extra}\">";
	$open_tag_inner = "";
	$close_tag = "</ul>";
	$close_tag_inner = "";
}


$the_query = new WP_Query($args);

if($style == 'list2'){
	remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
}

echo '<div class="row arexworks_show_product_shortcode woocommerce '.$el_class.'">';
if($title){
	echo '<div class="large-centered columns">';
		echo '<div class="heading-shortcode"><div class="heading-shortcode-wrap"><h2>'.$title.'</h2></div></div>';
	echo '</div>';
}
echo '<div class="large-12 columns">';
if($the_query->have_posts()){
	echo $open_tag;
	while($the_query->have_posts()){
		$the_query->the_post();
		echo $open_tag_inner;
		wc_get_template_part( 'content', 'product' );
		echo $close_tag_inner;
	}
	echo $close_tag;
}

echo '</div>';
echo '</div>';

if($style == 'list2'){
	add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
}

if($display_type == "top_rated_products"){
	remove_filter( 'posts_clauses',  array( WC()->query, 'order_by_rating_post_clauses' ) );
}
$woocommerce_loop['mode_view'] = '';
wp_reset_postdata();